<?php

/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
define('APP_ROOT', __DIR__);

spl_autoload_register(function($class){
    if(strpos($class, 'WH') !== false){
        $class = str_replace('WH\\', '', $class);
        $path = APP_ROOT . '/' . str_replace('\\', '/', $class) . '.php';
        //@TODO: check if file exists
        include_once $path;
    }
});

use WH\Api\Api;
$Api = new Api();


