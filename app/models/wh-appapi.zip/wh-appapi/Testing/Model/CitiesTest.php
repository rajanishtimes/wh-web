<?php

namespace WH\Testing\Model;

use WH\Model\Cities;

//require __DIR__ . "\..\..\Model\Cities.php";



class CitiesTest extends \PHPUnit_Framework_TestCase
{
    /**
     * @var Cities
     */
    protected $object;
 
    /**
     * Sets up the fixture, for example, opens a network connection.
     * This method is called before a test is executed.
     */
    protected function setUp()
    {
        $this->fetch = new Cities;
    }

    /**
     * Tears down the fixture, for example, closes a network connection.
     * This method is called after a test is executed.
     */
    protected function tearDown()
    {
    }

    /**
     * @covers WH\Model\Cities::allCities
     * @todo   Implement testAllCities().
     */
    public function testAllCities()
    {
        
    }

    /**
     * @covers WH\Model\Cities::getResults
     * @todo   Implement testGetResults().
     */
    public function testGetResults()
    {
        
    }

    /**
     * @covers WH\Model\Cities::setParam
     * @todo   Implement testSetParam().
     */
    public function testSetParam()
    {
        
    }
}
