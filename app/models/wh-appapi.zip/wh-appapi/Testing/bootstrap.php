<?php

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 * @author Rishabh.Trivedi
 */
// TODO: check include path
//ini_set('include_path', ini_get('include_path'));

// put your code here

define('APP_ROOT', __DIR__);
spl_autoload_register(function($class){
    if(strpos($class, 'WH') !== false){
        $class = str_replace('WH\\', '', $class);
		$pos = strpos(APP_ROOT, 'Testing');
		$path = substr(APP_ROOT, 0, $pos);
        $path = $path . str_replace('\\', '/', $class) . '.php';
        //@TODO: check if file exists
        include_once $path;
    }
});

function randomemail(){
	$tlds = array("com", "net", "gov", "org", "edu", "biz", "info");
	$char = "0123456789abcdefghijklmnopqrstuvwxyz";

	$ulen = mt_rand(5, 10);
	$dlen = mt_rand(7, 17);
	$a = "";
	for ($i = 1; $i <= $ulen; $i++) {
		$a .= substr($char, mt_rand(0, strlen($char)), 1);
	}
	$a .= "@";
	for ($i = 1; $i <= $dlen; $i++) {
		$a .= substr($char, mt_rand(0, strlen($char)), 1);
	}
	$a .= ".";
	$a .= $tlds[mt_rand(0, (sizeof($tlds)-1))];

	return $a;
}

function generaterandomno(){
	$ids = array();
	for($i=0; $i<=50; $i++){
		$ids[] = mt_rand(1, 999);
		//$ids[] = base64_encode(mt_rand(1, 999));
	}
	return $ids;
}

?>
