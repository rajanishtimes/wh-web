<?php

/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

namespace WH\Api\Services;

use WH\Api\Params;

class SolrApi{
    
    function searchEntity($params){
		
        $Search = new \WH\Model\Solr();
		
		$Search->setParam('reg_id',Params::getRegID($params));
		$Search->setParam('bycity',Params::getCity($params));
		$Search->setParam('lat',Params::getLat($params));
		$Search->setParam('lng',Params::getLong($params));
		$Search->setParam('start',Params::getStart($params));
		$Search->setParam('limit',Params::getLimit($params));
		$Search->setParam('byCategory',Params::getCategoryId($params));
		$Search->setParam('byDays',Params::getDays($params));
		$Search->setParam('byType',Params::getType($params));
		$Search->setParam('bysort',Params::getSort($params));
		$Search->setSolrType('search');
		
		$filter_type=Params::getFilterType($params);
		
		if($filter_type=='tags')
			$Search->setParam('byTags',Params::getSearchTerms($params));
		else
			$Search->setParam('searchname',Params::getSearchTerms($params));
		if(Params::getSearchTerms($params)==''){
			$Search->setParam('sponsored','true');
			$Search->setParam('spstart',Params::getStart($params));
			$Search->setParam('splimit',Params::getLimit($params));
		}
		
		$Search->setSearchEntity();
        	return $Search->getSearchResults();
    }
    
    function getDetail($params){
        $Solr = new \WH\Model\Solr();
		$Solr->setParam('reg_id',Params::getRegID($params));
		$Solr->setParam('ids',Params::getId($params));
		$Solr->setParam('fl','detail');
		$Solr->setSolrType('detail');
        $Solr->setEntityDetails();
        return $Solr->getDetailResults();
    }
	
    function autoSuggest($params){		
        $Suggestion = new \WH\Model\Solr();
		$Suggestion->setParam('reg_id',Params::getRegID($params));
		$Suggestion->setParam('searchname',Params::getletters($params));
		$Suggestion->setParam('bycity',Params::getCity($params));
		$Suggestion->setParam('byCategory',Params::getCategoryId($params));
		$Suggestion->setAutoSuggest();
        return $Suggestion->getSuggestResults();
    }
	
	function categoryCount($params){
		$CategoryCount = new \WH\Model\Solr();
		$CategoryCount->setParam('reg_id',Params::getRegID($params));
		$CategoryCount->setParam('bycity',Params::getCity($params));
		$CategoryCount->setCategoryCount();
        return $CategoryCount->getCategoryCountResult();
	}
}
