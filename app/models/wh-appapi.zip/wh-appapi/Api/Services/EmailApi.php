<?php

/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
namespace WH\Api\Services;
use WH\Api\Params;
use WH\Model\Core\Config;
use WH\Model\Core\Constants;

class EmailApi{
   
    function send($params){
        $Email = new \WH\Model\Core\Email();
		return $Email->sendEmail(Params::getFrom($params),Params::getEmail($params),Params::getSubject($params),Params::getBody($params),Params::getCampaign($params),Params::getSrc($params),Params::getTag($params));
    }
	
}
