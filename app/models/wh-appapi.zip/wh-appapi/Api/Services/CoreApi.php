<?php

/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
namespace WH\Api\Services;
use WH\Api\Params;
use WH\Model\Core\Config;
class CoreApi{
   
    function getCities($params){		
        $Newsletter = new \WH\Model\Cities();
        return $Newsletter->getResults();
    }
	
    function getCategories($params){		
        $Newsletter = new \WH\Model\Categories();
		$Newsletter->setParam('bycity',Params::getCity($params));
        return $Newsletter->getResults();
    }
	
	function getQuestions($params){		
        $questions = new \WH\Model\Questions();
		$questions->setParam('id',Params::getCityID($params));
        return $questions->getResults();
    }
	
	function getConstants($params){		
        $constants = new \WH\Model\Constants();
		$constants->setSource(Params::getSource($params));
        return $constants->getResults();
    }
	
	function getPopularTags($params){		
        $core = new \WH\Model\Core();
		$core->setCity(Params::getCityID($params));
        return $core->getResults();
    }
}

