<?php

/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

namespace WH\Api\Services;

use WH\Api\Params;

class UserApi{
   
    function unsubscribeNewsletter($params){		
        $Newsletter = new \WH\Model\User();
		$Newsletter->setNewsletter();
        $Newsletter->setEmail(Params::getEmail($params));
        return $Newsletter->getUnsubNewsletterResults();
    }
	
    function subscribeNewsletter($params){		
        $Newsletter = new \WH\Model\User();
		$Newsletter->setNewsletter();
        $Newsletter->setEmail(Params::getEmail($params));
        return $Newsletter->getNewsletterResults();
    }
	
	function profile($params){
		$Profile = new \WH\Model\User();
		$Profile->setId(Params::getId($params));
		$Profile->setProfile();
        return $Profile->getProfileResults();
	}
	
	function register($params){
		if(isset($_SERVER['REMOTE_ADDR'])){
			$remote_addr = $_SERVER['REMOTE_ADDR'];
		}else{
			$remote_addr = '127.0.0.1';
		}
		$Register = new \WH\Model\User();
		$Register->setParam('firstname',Params::getFirstname($params));
		$Register->setParam('lastname',Params::getLastname($params));
		$Register->setParam('emailid',Params::getEmail($params));
		$Register->setParam('password',Params::getPassword($params));
		$Register->setParam('ipaddress',$remote_addr);
		$Register->setParam('gender',Params::getGender($params));
		$Register->setParam('city',Params::getCity($params));
		$Register->setParam('state',Params::getState($params));
		$Register->setParam('mobile',Params::getMobile($params));
		$Register->setParam('pin',Params::getPin($params));
		$Register->setParam('sendmail',Params::getSendemail($params));
		$Register->setParam('dob',Params::getDob($params));
		$Register->setSSOParams();
        return $Register->registerUser();
	}
	
	function login ($params){
		$Login = new \WH\Model\User();
		$Login->setParam('login',Params::getEmail($params));
		$Login->setParam('passwd',Params::getPassword($params));
		$Login->setSSOParams();
		return $Login->loginUser();
	}
	
	function socialLogin($params){
		$Login = new \WH\Model\User();
		$Login->setParam('oauthid',Params::getOauthid($params));		
		$Login->setParam('oauthsiteid',Params::getOauthsiteid($params));//facebook or googleplus
		$Login->setParam('securitykey',Params::getSecuritykey($params));
		$Login->setParam('email',Params::getEmail($params));
		$Login->setParam('firstname',Params::getFirstname($params));
		$Login->setParam('lastname',Params::getLastname($params));
		$Login->setParam('gender',Params::getGender($params));
		$Login->setParam('hometown',Params::getHometown($params));
		$Login->setParam('location',Params::getLocation($params));
		$Login->setParam('imagepath',Params::getImagepath($params));
		$Login->setParam('reg_id',Params::getRegID($params));
		$Login->setSSOParams();
		return $Login->loginSocialUser();
	}
	
	function posts($params){
		$Posts = new \WH\Model\User();
		$Posts->setId(Params::getAuthorId($params));
		$Posts->setStart(Params::getStart($params));
		$Posts->setLimit(Params::getLimit($params));
		$Posts->setPostParams();
		return $Posts->getPostsResults();
	}
}