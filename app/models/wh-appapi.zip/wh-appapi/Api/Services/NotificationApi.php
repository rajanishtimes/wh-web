<?php

/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

namespace WH\Api\Services;

use WH\Api\Params;

class NotificationApi{
	
   function android($params){
		$Posts = new \WH\Model\Notification();
		$Posts->setDevice(Params::getDevice($params));
		$Posts->setData(Params::getData($params));
		$Posts->setMessage(Params::getMessage($params));
		return $Posts->getAndroidResults();
   }
   
   function iOS($params){
		$Posts = new \WH\Model\Notification();
		$Posts->setDevice(Params::getDevice($params));
		$Posts->setData(Params::getData($params));
		$Posts->setMessage(Params::getMessage($params));
		return $Posts->getiOSResults();
   }

   function schedule($params){
		$Posts = new \WH\Model\Notification();
		$Posts->setParam('token',Params::getDevice($params));
		$Posts->setParam('payload',Params::getData($params));
		$Posts->setParam('message',Params::getMessage($params));
		$Posts->setParam('campaign_name',Params::getCampaignName($params));
		$Posts->setParam('device_type',Params::getDeviceType($params));
		$Posts->setParam('scheduled_time',Params::getSchedule($params));
		return $Posts->getScheduleResults();
   }

   function track($params){
		$Posts = new \WH\Model\Notification();
		$Posts->setUKey(Params::getUKey($params));
		return $Posts->getTrackResults();
   }
   
   function sendbulkschedule($params){
		$PushNotification = new \WH\Model\Notification();
		$PushNotification->setThreadId(Params::getThreadid($params));
		return $PushNotification->getSchedulePushNotification();
   }

}