<?php

/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
namespace WH\Api\Services;
use WH\Api\Params;
use WH\Model\Core\Config;
use WH\Model\Core\Constants;

class ReportApi{
   
    function whlogs($params){
        $Report = new \WH\Model\Report();
		return $Report->allLogs();
    }
	
}
