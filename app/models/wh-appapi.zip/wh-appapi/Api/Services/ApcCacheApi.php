<?php

/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

namespace WH\Api\Services;

use WH\Model\Config\Config as Config;

class ApcCacheApi{
	
	function clear_key($params){
		if(isset($params['key']) && $params['key']!=''){
			if(apc_exists($params['key'])){
				apc_delete($params['key']);
				return 'APC Cache is deleted for '.$params['key'];
			}
			else
				throw new \Exception('There is no data for "'.$params['key'].'" in APC Cache',1);
		}
		else
			throw new \Exception('Invalid key',1);
	}
    
	function info(){
		return apc_cache_info();
	}
	
	function show($params){
		
		if(isset($params['key']) && $params['key']!=''){
			if(apc_exists($params['key'])){
				return apc_fetch($params['key']);
			}
			else
				throw new \Exception('There is no data for "'.$params['key'].'" in APC Cache',1);
		}
		else
			throw new \Exception('Invalid key',1);
	}
	
	function clear_all(){
		apc_clear_cache();
		return 'Whole APC Cache is deleted';
	}
	
}
