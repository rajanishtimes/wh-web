<?php

/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

namespace WH\Api\Services;

use WH\Api\Params;

class AppApi{
   
    function register($params){		
        $AppRegistration = new \WH\Model\AppRegistration(Params::getId($params),Params::getIdType($params),Params::getToken($params));
        return $AppRegistration->getResults();
    }
}