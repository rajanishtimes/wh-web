<?php

namespace WH\Api;
use WH\Model\Util\WhMongo;
use WH\Model\Util\Auth;
use WH\Model\Util\SQL;
use WH\Model\Util\StaticCon;
use WH\Model\Core\Config;
use WH\Model\SolrLogs;
use WH\Model\Core\Constants as C;

class Api{
    
    public $call = '';
    public $params = array();
    public $response = null;
    public $uri_parts = array();
    
    const MAPPING_TYPE_CLASS = 'CLASS';
    const MAPPING_TYPE_FUNCTION = 'FUNCTION';
    
    
    public function __construct($call = 'null', $params = array()){	
		
		$this->setStartTime(microtime(true)*1000);
		$this->setResponseDBParams();
		
        if($call == 'null'){
            $params = $_REQUEST;
            $call = $_SERVER['REQUEST_URI'];
        }
        $call_parts = explode('?', $call);
        $call = $call_parts[0];
        $this->setParams($params);
        $this->call = $call;
        
        $uri_parts = explode('/', $call);
        $uri_parts = array_slice($uri_parts, 2);
        $this->uri_parts = $uri_parts;
        if($this->auth($uri_parts)){
            try{
               $allData= $this->get();
                $response = array(
                    'status' => array(
                        'error' => 0,
                        'msg'   => ""
                    ),
                    'response'  => $this->response,
					'master_update_time'=>$this->masterUpdate()
                );
            } catch (\Exception $ex) {
				$this->storeException($ex->getCode(),$ex->getMessage());
                $response = array(
                    'status'    => array(
                        'error' => $ex->getCode(),
                        'msg'   => $ex->getMessage()
                    )
                );
            }
        }
		else{
			 $response = array(
				'status'    => array(
					'error' => 1,
					'msg'   => 'Unauthorized access'
				)
			);
		}
		
		  $this->render($response);
    }
    
    private function setParams($params){
        if(isSet($params['request'])){
            $paramsArr = json_decode($params['request'], true);
            if($paramsArr && is_array($paramsArr)){
                $this->params = $paramsArr;
            }else{
                $this->params = $params;
            }
            
        }else{
            $this->params = $params;
        }
    }
    
    private function getParams(){
        return $this->params;
    }
    
	private function setStartTime($time){
        $this->StartTime = $time;
    }
    
    private function getStartTime(){
        return $this->StartTime;
    } 
	private function setSolrResponseTime($time){
        $this->SolrResponseTime = $time;
    }
   
    private function getSolrResponseTime(){
		if(isset($this->SolrResponseTime))
        return $this->SolrResponseTime;
		else
			return 0;
    }
	private function setSolrStartTime($time){
        $this->SolrStartTime = $time;
    }
    
    private function getSolrStartTime(){
		if(isset($this->SolrStartTime))
        return $this->SolrStartTime;
		else
			return 0;
    }
	private function setSolrEndTime($time){
        $this->SolrEndTime = $time;
    }
    
    private function getSolrEndTime(){
		if(isset($this->SolrEndTime))
        return $this->SolrEndTime;
		else
			return 0;
    }
	
    private function getMapping($name, $type = ''){
        if($type == self::MAPPING_TYPE_CLASS){
            $name = 'Services\\'.ucfirst($name). 'Api';
        }
        return $name;
    }
    
    private function getClass(){
        $uri_parts = $this->uri_parts;
        if(isSet($uri_parts[0])){
            $class = $uri_parts[0];
            $class_name = $this->getMapping($class, self::MAPPING_TYPE_CLASS);
            $class_full_name = __NAMESPACE__ . "\\" . $class_name;
            /*
             * @TODO: add a check for file_exists before checking for class_exists
             */
            if(class_exists($class_full_name)){
                return $class_full_name;
            }
        }   
    }
    
    private function getFunction(){
        $uri_parts = $this->uri_parts;
        if(isSet($uri_parts[0])){
            $function = $uri_parts[1];
            return $this->getMapping($function, self::MAPPING_TYPE_FUNCTION);
        }
    }
    
    private function get(){
        $class_name = $this->getClass();
        if($class_name){
            $method_name = $this->getFunction();
            $Class = new $class_name();
            $params = $this->getParams();
            if(method_exists($Class, $method_name)){
                $response = $Class->{$method_name}($params);
            }else{
                $response = $class_name . " :: " . $method_name;
            }
            $this->response = $this->finalise($response, $method_name, $class_name);
			$this->storeResponsetime();
            return $response;
        }
    }
    
    private function auth($uri_parts){
		 if(!empty($uri_parts)){
			if(isset($uri_parts[0]) && $uri_parts[0]=='core' && isset($uri_parts[1]) && $uri_parts[1]=='getConstants'){
				$Auth=Auth::isValidRequest();
				return $Auth;
			}
			else
				return true;
		}
		else 
			return true;
    }
    
    public function render($response = false){
        $this->setContentType();
        if($response){
            echo json_encode($response);
        }
    }
    
    private function setContentType(){
        header('Content-Type: application/json');
    }
    
    private function finalise($response, $function_name, $class_name){
        /*
         * @TODO: Transform Logic
         */
        //if($response && is_array($response) && is_string($function_name)){
          //  $response = Params::map($response, $function_name);
        //}
        return $response;
    }
	
	private function setMongo($Mongo){
		$this->Mongo=$Mongo;
	}
	
	private function getMongo(){
		return $this->Mongo;
	}
	
	private function setResponseDBParams(){
		$Mongo = new WhMongo();
		$this->setMongo($Mongo);
	}
	

	private function storeResponsetime(){
		$Mongo=$this->getMongo();
		$Mongo->setCollection('api_logs');
		$call=$this->call;
		$params = $this->getParams();
		if(!empty($params))
			$allParams=json_encode($this->getParams());
		else
			$allParams='';
		$created=time();
		$response_time=microtime(true)*1000-$this->getStartTime();
		
		$Solr_time=SolrLogs::getResponseTime();
		$Solrget_time=SolrLogs::getPostSolrTime()-SolrLogs::getPreSolrTime();
		$created=time();
		$data=array('call'=>$call,'params'=>$allParams,'response_time'=>$response_time,'created'=>$created,'solr_time'=>$Solr_time,'solr_call_time'=>$Solrget_time,'env'=>C::env(),'created_on'=>$created);
		$saveData=$Mongo->save($data);
		
	}
	private function storeException($code,$message){
		$Mongo=$this->getMongo();
		$Mongo->setCollection('api_error_logs');
		$call=$this->call;
		$params = $this->getParams();
		if(!empty($params))
			$allParams=json_encode($this->getParams());
		else
			$allParams='';
		$created=time();
		$data=array('call'=>$call,'params'=>$allParams,'error_code'=>$code,'error_message'=>$message,'ip'=>$_SERVER['REMOTE_ADDR'],'error_date'=>$created);
		$saveData=$Mongo->save($data);
		
	}
	private function masterUpdate(){
		$SQL=StaticCon::getMySqlCon('CmsDB');
		$time='';
		$masperUpdateTime=$SQL->select('constant_value')->from('tc_constants')->where(array('constant_name'=>'master_update_time'))->get()->result_object();
		if(isset($masperUpdateTime[0]->constant_value)){
			$time=$masperUpdateTime[0]->constant_value;
		}
		return $time;
	}
}

?>
