<?php

/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

namespace WH\Api;
use WH\Model\Core\Constants as C;

class Params{
    
    static function getCity($params){
        if(isSet($params['city']) && is_string($params['city'])){
            $city= $params['city'];
			
        }else if(isSet($params['city_id'])){
            $city= $params['city_id'];
			
        }else {
            throw new \Exception("City not available",1);
        }
		if(is_numeric($city)){
            $city = C::getCityName($city);
        }
		
		return $city;
    }
    
    static function getCityID($params){
        if(isSet($params['city']) && is_string($params['city'])){
            $city= $params['city'];
			$city = C::getCityId($city);
        }else if(isSet($params['city_id'])){
            $city= $params['city_id'];
			
        }else {
            throw new \Exception("City not available",1);
        }
		return $city;
    }
    
    static function getLat($params){
        if(isSet($params['lat'])){
            return (float)$params['lat'];
        }
    }
    
    static function getLong($params){
        if(isSet($params['long'])){
            return (float)$params['long'];
        }
    }
    
    static function getSearchTerms($params){
        if(isSet($params['keywords'])){
            return $params['keywords'];
        }
    }
    
    static function getCategoryId($params){
        if(isSet($params['category_id'])){
            return C::getCategoryName($params['category_id']);
        }
    }
    
    static function getTimeFilter($params){
        if(isSet($params['time'])){
            return $params['time'];
        }
    }
	 
    static function getletters($params){
        if(isSet($params['letters'])){
            return $params['letters'];
        }
    } 
	  
    static function getFilterType($params){
        if(isSet($params['filter_type'])){
            return $params['filter_type'];
        }
    } 
	  
    static function getRegID($params){
        if(isSet($params['reg_id'])){
            return $params['reg_id'];
        }
    } 
	 
    static function getOauthid($params){
        if(isSet($params['oauthid'])){
            return $params['oauthid'];
        }
		else
			throw new \Exception("Oauthid is empty",1); 
    }
    static function getDevice($params){
        if(isSet($params['device'])){
            return $params['device'];
        }
		else
			throw new \Exception("Device is empty",1); 
    }
	 
    static function getSource($params){
        if(isSet($params['source'])){
            return $params['source'];
        }
		else
			throw new \Exception("Source is empty",1); 
    } 
    static function getMessage($params){
        if(isSet($params['message'])){
            return $params['message'];
        }
		else
			throw new \Exception("Message is empty",1); 
    } 
    static function getData($params){
        if(isSet($params['data'])){
            return $params['data'];
        } 
    } 
    static function getSubject($params){
        if(isSet($params['subject']) && trim($params['subject'])!=''){
            return $params['subject'];
        }
		else
			throw new \Exception("Invalid subject",1); 
    } 
    static function getFrom($params){
        if(isSet($params['from_name']) && trim($params['from_name'])!=''){
            return $params['from_name'];
        }
		else
			throw new \Exception("Invalid From Name",1); 
    } 
    static function getBody($params){
        if(isSet($params['body']) && trim($params['body'])!=''){
            return $params['body'];
        }
		else
			throw new \Exception("Invalid body",1); 
    } 
    static function getCampaign($params){
        if(isSet($params['campaign'])){
			if(trim($params['campaign'])!='')
				 return $params['campaign'];
			 else
				 throw new \Exception("Invalid Campaign",1); 
		}
           
		else
			return 'wh_default';
    } 
    static function getCampaignName($params){
        if(isSet($params['campaign']))
            return $params['campaign'];
    } 
    static function getSrc($params){
        if(isSet($params['src']))
            if(trim($params['src'])!='')
				 return $params['src'];
			 else
				 throw new \Exception("Invalid Src",1); 
		else
			return 'whatshot'; 
    }  
    static function getTag($params){
        if(isSet($params['tag']))
            if(trim($params['tag'])!='')
				 return $params['tag'];
			 else
				 throw new \Exception("Invalid Tag",1); 
		else
			return '_blank_'; 
    } 
    static function getOauthsiteid($params){
        if(isSet($params['oauthsiteid'])){
            return $params['oauthsiteid'];
        }
		else
			throw new \Exception("Oauthsiteid is empty",1); 
    } 
    static function getSecuritykey($params){
        if(isSet($params['securitykey'])){
            return $params['securitykey'];
        }
		else
			throw new \Exception("Security key is empty",1);
    } 
    static function getHometown($params){
        if(isSet($params['hometown'])){
            return $params['hometown'];
        }
    } 
    static function getLocation($params){
        if(isSet($params['location'])){
            return $params['location'];
        }
    } 
    static function getImagepath($params){
        if(isSet($params['imagepath'])){
            return $params['imagepath'];
        }
    } 
    static function getSort($params){
		if(isSet($params['sort_by'])){
            			return $params['sort_by'];
		}else{
			if(isSet($params['keywords'])){
				$sort=1;
			}
			else{
				if(isSet($params['time']) && strtolower($params['time']) != 'all' ){
					$sort=4;
				}
				else{
					$sort=2;
				}
			}
			return $sort;
		}
        	
    } 
    static function getDays($params){
        if(isSet($params['time'])){
			$params['time']=strtolower($params['time']);
			$params['time']=ucwords($params['time']);
			if($params['time']!='All')
				return $params['time'];
		}
    } 
    static function getType($params){
        if(isSet($params['type']))
            return $params['type'];
		else
			return 'Event,Content';
    }  
    static function getDeviceType($params){
        if(isSet($params['device_type']))
            return $params['device_type'];
    }  
    static function getSchedule($params){
        if(isSet($params['schedule_time']))
            return $params['schedule_time'];
		throw new \Exception("Schedule Time not available",1);
    } 
    static function getUKey($params){
        if(isSet($params['ukey']))
            return $params['ukey'];
		throw new \Exception("uKey not available",1);
    } 
    static function getStart($params){
        if(isSet($params['start']) && $params['start']!='')
            return $params['start'];
		else
			return 0;
    } 
    static function getLimit($params){
        if(isSet($params['limit']) && $params['limit']!='')
            return $params['limit'];
        else
			return 10;
    }
    static function getEmail($params){
        if(isSet($params['email'])){
			if (filter_var($params['email'], FILTER_VALIDATE_EMAIL))
				return $params['email'];
			else
				throw new \Exception("This email is not valid, please check",1); 
        }
		else {
            throw new \Exception("Email not available",1);
        }
    }
	static function getAuthorId($params){
        if(isSet($params['id']) && is_string($params['id']))
            return $params['id'];
		else 
            throw new \Exception("Author ID not available",1);
        
    }
	static function getId($params){
        if(isSet($params['id']) && is_string($params['id']))
            return $params['id'];
		else 
            throw new \Exception("ID not available",1);
        
    }
	static function getIdType($params){
       if(isSet($params['id_type']) && is_string($params['id_type']))
            return $params['id_type'];
		else 
            throw new \Exception("ID Type not available",1);
        
    }
	static function getToken($params){
        if(isSet($params['token']) && is_string($params['token']))
            return $params['token'];
		else 
            throw new \Exception("Token not available",1);
        
    }
	static function getFirstname($params){
        if(isSet($params['first_name']) && is_string($params['first_name']))
            return $params['first_name'];
    }
	static function getLastname($params){
        if(isSet($params['last_name']) && is_string($params['last_name']))
            return $params['last_name'];
    }
	
	static function getPassword($params){
        if(isSet($params['password']) && is_string($params['password']))
            return $params['password'];
		else 
            throw new \Exception("Password not available",1);
        
    }
	
	static function getGender($params){
        if(isSet($params['gender']) && is_string($params['gender']))
            return $params['gender'];
    }
	
	static function getState($params){
        if(isSet($params['state']) && is_string($params['state']))
            return $params['state'];
    }
	
	static function getMobile($params){
        if(isSet($params['mobile']) && is_string($params['mobile']))
            return $params['mobile'];
    }
	
	static function getPin($params){
        if(isSet($params['pin']) && is_string($params['pin']))
            return $params['pin'];
    }
	
	static function getSendemail($params){
        if(isSet($params['sendemail']) && is_string($params['sendemail']))
            return $params['sendemail'];
    }
	
	static function getDob($params){
        if(isSet($params['dob']) && is_string($params['dob']))
            return $params['dob'];
    }
	static function getAllCategories($allCategories){
		$categories=array();
		if(isset($allCategories['categories']) && !empty($allCategories['categories'])){
			foreach($allCategories['categories'] as $category){
				$categories[]=$category['name'];
			}
		}
		return $categories;
	}
	static function getThreadid($params){
		return $params['thread_id'];
    }
}
