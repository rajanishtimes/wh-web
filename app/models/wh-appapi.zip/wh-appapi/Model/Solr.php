<?php

/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
namespace WH\Model;

use WH\Model\Util\Curl;
use WH\Model\Util\SolrApi;
use WH\Model\Core\Constants as C;
class Solr{
   
    // Params
    private $params = array();

    // Response components
    private $response;
    private $matchCount = 0;
    private $results = array();
    private $facets = array();
    
    public function setSearchEntity(){
		$SolrApi = new SolrApi();
        $SolrApi->setApiType('search/getresult');
        $SolrApi->setResultType('processSearchResult');
		$SolrApi->setParams($this->getParams());
		
		$allparams=$this->getParams();
		
		if(!isset($allparams['start']))
		$allparams['start']=0;
	
		if(!isset($allparams['limit']))
		$allparams['limit']=10;
		
		$this->setStart($allparams['start']);
		$this->setLimit($allparams['limit']);
		if(isset($allparams['bysort']))
		$this->setSortBy($allparams['bysort']);
        $this->setSolrApi($SolrApi);
	}
	
    public function setAutoSuggest(){
		$SolrApi = new SolrApi();
        $SolrApi->setApiType('auto/getresult');
        $SolrApi->setResultType('processAutosuggestResult');
		$SolrApi->setParams($this->getParams());
        $this->setSolrApi($SolrApi);
	}
	
    public function setEntityDetails(){
		$SolrApi = new SolrApi();
        $SolrApi->setApiType('idsearch/getresult');
        $SolrApi->setResultType('processSearchResult');
		$SolrApi->setParams($this->getParams());
        $this->setSolrApi($SolrApi);
	}
	
	  
    public function setCategoryCount(){
		$SolrApi = new SolrApi();
        $SolrApi->setApiType('search/getresult');
        $SolrApi->setResultType('processCategoryCountResult');
		$SolrApi->setParams($this->getParams());
        $this->setSolrApi($SolrApi);
	}
	
    function setParam($name, $value){
        if($name && $value){
            $this->params[$name] = $value;
        }
    }
    
    private function getParams(){
        return $this->params;
    }
	 
    private function setSolrApi($Solr){
        $this->SolrApi = $Solr;
    }
    
    private function getSolrApi(){
        return $this->SolrApi;
    }
	 
    private function setStart($start){
        $this->start = $start;
    }
    
    private function getStart(){
        return $this->start;
    }
	 
    public function setAllCategories($allcategories){
        $this->allCategories = $allcategories;
    }
    
    private function getAllCategories(){
        return $this->allCategories;
    }
	 
    private function setLimit($limit){
        $this->limit = $limit;
    }
    
    private function getLimit(){
        return $this->limit;
    }
	  
    public function setSolrType($SolrType){
        $this->SolrType = $SolrType;
    }
    
    private function getSolrType(){
		if(isset($this->SolrType))
			return $this->SolrType;
		else
			return '';
    }
	 
    private function setSortBy($sort){
        $this->sortBy = $sort;
    }
    
    private function getSortBy(){
		if(isset($this->sortBy))
        return $this->sortBy;
    }
	
	 function getSearchResults (){
        $Solr=$this->getSolrApi();
		$Solr->setSolrType($this->getSolrType());
        $Solr->call();
        $results = $Solr->getResults();
		$meta['match_count']=$Solr->getMatchCount();
		$meta['sort']=C::getSortContent($this->getSortBy());
		$meta['start']=$this->getStart();
		$meta['limit']=$this->getLimit();
        return array(
            'meta'      => $meta,
            'results'   => $results,
        );
    }
	
	 function getSuggestResults (){
        $Solr=$this->getSolrApi();
        $Solr->call();
        $results = $Solr->getResults();
		$meta['match_count']=$Solr->getMatchCount();
        return array(
			'meta'      => $meta,
            'suggestions'   => $results,
        );
    }
	 function getDetailResults (){
        $Solr=$this->getSolrApi();
        $Solr->call();
        $results = $Solr->getResults();
		if(isset($results[0]))
			$results=$results[0];
		else
			$results=null;
        return $results;
    }
	
	function getCategoryCountResult(){
		$results=array();
		$Solr=$this->getSolrApi();
		$results['counts'] = $Solr->processCategoryCountResult();
		return $results;
	}
}
