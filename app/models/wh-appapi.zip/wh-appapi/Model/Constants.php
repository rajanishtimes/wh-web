<?php

/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

namespace WH\Model;
use WH\Model\Util\StaticCon;
use WH\Model\Util\SQL;

class Constants{
    
    private $results = array();
    private $SQL = null;
    
    function __construct() {
        $SQL=StaticCon::getMySqlCon('CmsDB');
        $this->setSQL($SQL);
    }
   
    function getResults (){
		$SQL=$this->getSQL();
        $where=array('source'=>$this->getSource());
		$return=array();
		$query1=$SQL->select('constant_value,constant_name')->from('tc_constants')->where($where)->get();		
		$appexists=$SQL->num_rows();
		$result=$SQL->result();
		if($appexists>0)
		{
			if(!empty($result)){
				foreach($result as $res){
					$return[$res->constant_name]=$res->constant_value;
				}
			}
			 
		}
		return array(
				'constants'   => $return,
			);
    }
    
    private function setSQL($SQL){
        $this->SQL = $SQL;
    }
    
    private function getSQL(){
        return $this->SQL;
    }
    public function setSource($Source){
        $this->Source = $Source;
    }
    
    private function getSource(){
        return $this->Source;
    }
	public function setParam($name, $value){
        if($name && $value){
            $this->params[$name] = $value;
        }
    }
    
    private function getParams(){
        return $this->params;
    }
}