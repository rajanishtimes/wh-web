<?php

/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

namespace WH\Model;
use WH\Model\Util\AndroidPushNotification;
use WH\Model\Util\iOSPushNotification;
use WH\Model\Util\SQL;
use WH\Model\Util\StaticCon;
use WH\Api\Params;
use WH\Model\Core\Constants as C;

class Notification{
    
    private $results = array();
    
    function __construct() {
        $SQL=StaticCon::getMySqlCon('frontEndDB');
		$this->setSQL($SQL);
    }
	
    public function setSQL($sql){
        $this->SQL = $sql;
    }
    
    private function getSQL(){
        return $this->SQL;
    }
	
    public function setDevice($device){
        $this->device = $device;
    }
    
    private function getDevice(){
        return $this->device;
    }
	
    public function setData($data){
        $this->data = $data;
    }
    
    private function getData(){
        return $this->data;
    }
	
    public function setUKey($ukey){
        $this->ukey = $ukey;
    }
    
    private function getUKey(){
        return $this->ukey;
    }
	
    public function setMessage($message){
        $this->message = $message;
    }
    
    private function getMessage(){
        return $this->message;
    }
	 public function setDeviceType($DeviceType){
        $this->DeviceType = $DeviceType;
    }
    
    private function getDeviceType(){
        return $this->DeviceType;
    }
	
    function setParam($name, $value){		
        if($name && $value){
            $this->params[$name] = $value;
        }
    }
	
	private function getParams(){
        return $this->params;
    }

	function setThreadId($value){
        $this->threadid = $value;
    }
	
	private function getThreadId(){
        return $this->threadid;
    }

	private function offwarning(){
		error_reporting(0);
	}
	
	public function getiOSResults(){
		$device=$this->getDevice();
		$data=$this->getData();
		$message=$this->getMessage();
		$this->setDeviceType(2);
		$savedID=$this->saveRequestInDb();
		
		if($data!=''){
			$data=json_decode($data);
		}
		
		$iOS=new iOSPushNotification();
		$uKey=$this->getUKey();
		$response=$iOS->send($device,$message,$uKey,$data);
		$this->processResponse($response,$savedID);
		return $response;	
	}
	
	public function getScheduleResults(){
		$response=$this->saveScheduleInDb();
		return $response;	
	}
	
	public function getSchedulePushNotification(){
		$response=$this->sendSchedulefromdb();
		return $response;	
	}
	
	public function getAndroidResults(){
		$device=$this->getDevice();
		$data=$this->getData();
		$message=$this->getMessage();
		$this->setDeviceType(1);
		if($data!=''){
			$data=json_decode($data);
		}
		$savedID=$this->saveRequestInDb();
	    $an = new AndroidPushNotification('AIzaSyCWPesw5LqtZ9oLoK8Q5j2czKZSiFWGIkM');		
		$an->setDevices($device);
		$uKey=$this->getUKey();
		$response = $an->send($message,$data,$uKey);
		$response=json_decode($response);
		$this->processResponse($response,$savedID);
		return $response;
		
	}
	
	public function getTrackResults(){
		$ukey=$this->getUkey();
		
		$SQL=$this->getSQL();
		$update=array('status'=>4,'last_updated'=>date('Y-m-d H:i:s'));
		$where=array('ukey'=>$ukey);
		$query=$SQL->update('wh_pn_notifications',$update,$where);
		if($query){
			$return['success']=1;
			$return['success']='Opened track is updated successfully!';
			return $return;
		}
			
		else
			throw new \Exception("Something went wrong!",1);
		
		return $response;
		
	}
	
	private function processResponse($response,$savedID){
		if(isset($response->success))
			$success=$response->success;
		else
			$success=$response['success'];
		if(isset($success) && $success==1)
			$this->successUpdates($savedID);
		else
			$this->failureUpdates($savedID);
		
		return $response;
	}
	
	private function successUpdates($id){
		$SQL=$this->getSQL();
		$update=array('status'=>3,'last_updated'=>date('Y-m-d H:i:s'));
		$where=array('id'=>$id);
		$query=$SQL->update('wh_pn_notifications',$update,$where);
		if($query)
			return true;
		else
			throw new \Exception("Something went wrong!",1);
	}
	
	private function failureUpdates($id){
		$SQL=$this->getSQL();
		$update=array('status'=>'-1');
		$where=array('id'=>$id);
		$query=$SQL->update('wh_pn_notifications',$update,$where);
		if($query)
			return true;
		else
			throw new \Exception("Something went wrong!",1);
	}
	
	private function saveRequestInDb(){
		$uKey=time();
		$this->setUKey($uKey);
		$data=array(
				'token'=>$this->getDevice(),
				'message'=>$this->getMessage(),
				'time_added'=>date('Y-m-d H:i:s'),
				'payload'=>$this->getData(),
				'device_type'=>$this->getDeviceType(),
				'status'=>2,
				'ukey'=>$uKey
		);
		
		$SQL=$this->getSQL();
		$query=$SQL->insert('wh_pn_notifications',$data);
		if($query)
			return $SQL->insert_id();
		else
			throw new \Exception("Something went wrong!",1);
	}
	
	
	private function saveScheduleInDb(){
		$data=$this->getParams();
		if(isset($data['scheduled_time']))
			$data['scheduled_time'] = date('Y-m-d H:i:s',strtotime($data['scheduled_time']));
		
		$data['status']=1;
		$data['ukey']=time();
		$data['time_added']=date('Y-m-d H:i:s');
		
		$SQL=$this->getSQL();
		$query=$SQL->insert('wh_pn_notifications',$data);
		if($query){
				$return['success']=1;
				$return['message']='Schedule is saved successfully!';
				return $return;
		}
		else
			throw new \Exception("Something went wrong!",1);
	}
	
	private function sendSchedulefromdb(){
		$this->offwarning();
		$result_for_sent = $this->getSchedulesentrecord();
		
		$iOS=new iOSPushNotification();
		$an = new AndroidPushNotification('AIzaSyCWPesw5LqtZ9oLoK8Q5j2czKZSiFWGIkM');		
		
		foreach($result_for_sent as $sentdata){
			$message = $sentdata['message'];
			$token = $sentdata['token'];
			if($sentdata['device_type'] == 1){
				$response=$iOS->send($token, $message);
				$this->processResponse($response,$sentdata['id']);
			}else if($sentdata['device_type'] == 2){
				$an->setDevices($token);
				$response = $an->send($message);
				$response=json_decode($response);
				$this->processResponse($response,$sentdata['id']);
			}
		}
		
		$return['success']=1;
		$return['message']='Schedule sent successfully!';
		return $return;
	}
	
	private function getSchedulesentrecord(){
		$limit = 100;
		$thread_id = $this->getThreadId();
		$SQL=$this->getSQL();
		$updateconditions = array();
		if(!empty($thread_id))
			$updateconditions['thread_id'] = $thread_id;
		$updateconditions['status'] = 2;
		$updateconditions['last_updated'] = date('Y-m-d H:i:s');
		
		$conditions = array();
		$conditions['status'] = 1;
		$conditions['scheduled_time <'] = date('Y-m-d h:i:s', time());
		$query=$SQL->update('wh_pn_notifications',$updateconditions,$conditions,$limit);
		
		$conditions = array();
		if(!empty($thread_id))
			$conditions['thread_id'] = $thread_id;
		$conditions['status'] = 2;
		$conditions['scheduled_time <'] = date('Y-m-d h:i:s', time());
		$result_for_sent = $SQL->select('*')->from('wh_pn_notifications')->where($conditions)->get()->result_array();
		return $result_for_sent;
	}
	
}