<?php

/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
namespace WH\Model;

class SolrLogs{
   static public $ResponseTime;
   static public $PreSolrTime;
   static public $PostSolrTime;

    public static function setResponseTime($ResponseTime){
        self::$ResponseTime = $ResponseTime;
    }
    
    public static function getResponseTime(){
		if(isset(self::$ResponseTime))
			return self::$ResponseTime;
		else
			return 0;
    }
	
    public static function setPreSolrTime($PreSolrTime){
        self::$PreSolrTime = $PreSolrTime;
    }
    
    public static function getPreSolrTime(){
		if(isset(self::$PreSolrTime))
			return self::$PreSolrTime;
		else
			return 0;
    }
	
    public static function setPostSolrTime($PostSolrTime){
        self::$PostSolrTime = $PostSolrTime;
    }
    
    public static function getPostSolrTime(){
		if(isset(self::$PostSolrTime))
			return self::$PostSolrTime;
		else
			return 0;
    }
	
}
