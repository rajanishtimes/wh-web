;<?php die(); ?>
[default_mongo]
server = 192.169.31.161
server2 = 192.169.31.161
readPreference = primaryPreferred
port = 27017
db = wh_main

[devcms]
host=192.169.34.186;
dbname=whdev;
username=whFire;
password=Times@123;

[qccms]
host=192.169.34.186;
dbname=whqc;
username=whFire;
password=Times@123;

[contentcms]
host=192.169.34.186;
dbname=whcontent;
username=whFire;
password=Times@123;

[stagingcms]
host=192.169.34.185;
dbname=wheel;
username=fireBird;
password=FHW%aw1;

[frontend]
host=192.169.34.186;
dbname=whweb;
username=whFire;
password=Times@123;
