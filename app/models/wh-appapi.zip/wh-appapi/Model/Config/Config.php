<?php

namespace WH\Model\Config;

define('MONGO_APP_ROOT', dirname(__FILE__) . DIRECTORY_SEPARATOR );
define('CONF_FILE', MONGO_APP_ROOT . 'config.ini.php'); 

class Config {
    
    const VERSION = '1.1';
    static public $conf = array();
    
    function __construct() {
        self::load();
    }
    
    static private function load() {
        self::$conf = parse_ini_file(CONF_FILE, true);
    }
    
    static public function get($conf_name = null) {
        if (empty(self::$conf)) self::load();
        if (isset(self::$conf[$conf_name])) {
            return self::$conf[$conf_name];
        }
        
        return false;
    }
    
    static public function set($conf_name, Array $conf) {
        if (!empty($conf_name)) self::$conf[$conf_name] = $conf;
    }
    
    static public function getAll() {
        if (empty(self::$conf)) self::load();
        return self::$conf;
    }
   
   
}

?>
