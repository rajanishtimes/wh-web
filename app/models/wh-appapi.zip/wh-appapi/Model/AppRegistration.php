<?php

/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

namespace WH\Model;
use WH\Model\Util\StaticCon;
use WH\Model\Util\SQL;

class Appregistration{
    
    private $results = array();
     private $Mongo = null;
    
    function __construct($id,$id_type,$token) {
		$SQL=StaticCon::getMySqlCon('frontEndDB');
		$this->setSQL($SQL);
        $this->setId($id);
        $this->setIdType($id_type);
        $this->setToken($token);
    }
   
    function getResults (){
		$results=array();
		$this->checkIfAppExists();	
		$this->insertAppDetails();
		$results = $this->getProcessResults();	
        return $results;
    }
    
    private function setEmail($email){
        $this->Email = $email;
    }
    
    private function getEmail(){
        return $this->Email;
    }
	
    private function setId($id){
        $this->Id = $id;
    }
    
    private function getId(){
        return $this->Id;
    }
	
    private function setIdType($id_type){
        $this->IdType = $id_type;
    }
    
    private function getIdType(){
        return $this->IdType;
    }
	
    private function setToken($Token){
        $this->Token = $Token;
    }
    
    private function getToken(){
        return $this->Token;
    }
	
	private function getProcessResults(){
		return array(
			'done'=>1,
			'message'=>'App is registered successfully'
		);
		
	}
	
	public function setSQL($sql){
        $this->SQL = $sql;
    }
    
    private function getSQL(){
        return $this->SQL;
    }
	
	private function checkIfAppExists(){
		$SQL=$this->getSQL();
		$reg_id=$this->getId();
		$id_type=$this->getIdType();
		$where=array('reg_id'=>$reg_id,'type'=>$id_type);
		$query1=$SQL->select('*')->from('wh_pn_tokens')->where($where)->get();		
		$appexists=$SQL->num_rows();
		if($appexists>0)
			throw new \Exception("This app is already registered",1);
	}

	private function insertAppDetails(){
		$SQL=$this->getSQL();
		$reg_id=$this->getId();
		$IdType=$this->getIdType();
		$Token=$this->getToken();
		$data=array('reg_id'=>$reg_id,'type'=>$IdType,'token'=>$Token,'time_added'=>date('Y-m-d H:i:s'),'is_installed'=>1);
		$query=$SQL->insert('wh_pn_tokens',$data);
		if($query)
			return $SQL->insert_id();
		else
			throw new \Exception("Something went wrong!",1);
	}

}