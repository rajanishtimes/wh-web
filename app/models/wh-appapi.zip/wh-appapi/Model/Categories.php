<?php

/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

namespace WH\Model;

use WH\Model\Util\CmsApi;

class Categories{
    
    private $results = array();
    private $CmsApi = null;
    
    function __construct() {
		
        $CmsApi = new CmsApi();
        $CmsApi->setApiType('category/index');
        $CmsApi->setResultType('processCategory');
        $this->setCmsApi($CmsApi);
        
    }
    
    function getResults (){
        $CmsApi = $this->getCmsApi();
		
        $CmsApi->call();
        $CmsApi->setParams($this->getParams());
		
        $results = $CmsApi->getResults();
        return array(
            'categories'   => $results,
        );
    }
    
    private function setCmsApi($CmsApi){
        $this->CmsApi = $CmsApi;
    }
    
    private function getCmsApi(){
        return $this->CmsApi;
    }
	
	public function setParam($name, $value){
        if($name && $value){
            $this->params[$name] = $value;
        }
    }
    
    private function getParams(){
		if(isset($this->params) && !empty($this->params))
        return $this->params;
    }
    
	//THIS FUNCTION IS CALLED FROM CONSTANT FILE
	
	function allCategories(){
		if (!apc_exists('categories')){
			$CmsApi = $this->getCmsApi();
			$CmsApi->call();
			$results = $CmsApi->getResults();
			$data=$this->processConstantCategories($results);
			apc_add('categories',$data);
		}
		return apc_fetch('categories');
	}
	
	private function processConstantCategories($results){
		$return=array();
		if(!empty($results)){
			foreach($results as $result){
				$return[$result['id']]=$result['name'];
			}
		}
		return $return;
	}
}