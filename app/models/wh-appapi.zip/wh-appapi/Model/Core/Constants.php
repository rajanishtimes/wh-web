<?php

namespace WH\Model\Core;
use WH\Model\Cities;

class Constants{
   
   static function root(){
	  return $_SERVER['DOCUMENT_ROOT'];
   }
   
   static function base(){
	  return $_SERVER['SERVER_NAME'];
   }
   
   static function env(){
	  return 'appapi';
   }
   
    static function getCities(){
		$cities = new \WH\Model\Cities();
		$citiesList=$cities->allCities();
		return $citiesList;
    }
    
    static function getCategories(){
        $categories = new \WH\Model\Categories();
		$categoriesList=$categories->allCategories();
		return $categoriesList;
    }
    
    static function getCategoryName($cat_id){
		$categories=Constants::getCategories();
        if(isSet($categories[$cat_id])){
            return $categories[$cat_id];
        }
    }
    
    static function getCategoryId($category){
        $category = ucwords(strtolower($category));
        $categories = Constants::getCategories();
        $r_categories = array_flip($categories);
        if(isSet($r_categories[$category])){
            return $r_categories[$category];
        }
    }
    
    static function getCityName($city_id){
		$cities=Constants::getCities();
        if(isSet($cities[$city_id])){
            return $cities[$city_id];
        }
    }
    
    static function getCityId($city){
        $city = ucwords(strtolower($city));        
        $cities = Constants::getCities();
        $r_cities = array_flip($cities);
        if(isSet($r_cities[$city])){
            return $r_cities[$city];
        }
    }
	static function getSortTypes(){
		return array('1'=>'By Relevance','2'=>'By Popularity','3'=>'By Time','4'=>'By Time');
	}
	
	static function getSortContent($sort_by){
		$sort=Constants::getSortTypes();
		if($sort_by){
        if(isSet($sort[$sort_by]))
            return $sort[$sort_by];
		else
			return '';
		}
		else{
			return $sort[1];
		}
    }
}
