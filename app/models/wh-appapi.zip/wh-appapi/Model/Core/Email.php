<?php

namespace WH\Model\Core;
use WH\Model\Util\StaticCon;
use WH\Model\Util\WhMongo;
use WH\Model\Core\Constants as C;
use MongoId as MongoId;  
 
class Email{
	
	public function sendEmail($fromname,$email,$subject,$body,$campaign,$src,$tag){
		$token=$this->getToken();		
		$image='<img src="http://'.C::base().'/'.C::env().'/c.gif?token='.$token.'">';
		$message = $body.'<br/><br/>'.$image;
		
		require_once C::root(). '/'.C::env().'/Lib/PHPMailer/PHPMailerAutoload.php';
        $mail = new \PHPMailer;
        $mail->isSMTP();                                      // Set mailer to use SMTP
        $mail->Host = 'cmailer.indiatimes.com';  // Specify main and backup server
        $mail->SMTPAuth = false;                               // Enable SMTP authentication
        $mail->Port = 25;  
		//$mail->SMTPDebug  = 1;
        $mail->From = 'info@whatshot.in';
        $mail->FromName = $fromname; 
        $mail->addAddress($email);
        $mail->isHTML(true);                                  // Set email format to HTML
    
        $mail->Subject = $subject;
        $mail->Body    = $message;
        if(!$mail->send()) { 
            $return['status']=0;
			$return['message']= $mail->ErrorInfo;
			$return['ukey']=$token;
			return $return;
        }else{
            $this->saveEmailInDb($email,$subject,$message,$campaign,$src,$tag,$token);				
			$return['status']=1;
			$return['message']='Success';
			$return['ukey']=$token;
			return $return;
        }
	}
	
    function setParam($name, $value){
        if($name && $value){
            $this->params[$name] = $value;
        }
    }
	
    private function getParams(){
        return $this->params;
    }
	
	private function getToken(){
		return substr(str_shuffle("0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ"), 0, 20);
	}
	
	private function saveEmailInDb($email,$subject,$body,$campaign,$src,$tag,$token){
		//$Mongo=StaticCon::getMongoCon('default_mongo');
		$Mongo = new WhMongo();
		$Mongo->setCollection('emails');
		$data=array('email'=>$email,'subject'=>$subject,'body'=>$body,'campaign'=>$campaign,'src'=>$src,'tag'=>$tag,'token'=>$token,'time_added'=>time(),'open_count'=>0,'opened_time'=>'');
		$saveData=$Mongo->save($data);
	}
}
