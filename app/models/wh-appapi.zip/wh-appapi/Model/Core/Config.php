<?php

namespace WH\Model\Core;
use WH\Model\Util\WhMongo;
use WH\Model\Util\StaticCon;
class Config{
	
	static $conf = null;
	static $Mongo = null;
	static $Name = null;
	static $database_type ='mongo';					//for picking up the config ( mysql / mongo )
	static $database_credentials ='default_mongo'; 	//to connect to conf DB
	static $cache_type = 'APC';						//APC/Redis
	static $application_prefix = 'appapi_dev'; 	//to uniquely identify and retrieve conf from DB 
	
	static function get($name){
		self::init();
		$conf = self::$conf;
		if(!empty($conf)){
			foreach($conf as $indivConf){
				if($indivConf['name']==$name)
					return $indivConf['value'];
			}
		}
	}
	
	static function init(){
		if(self::$conf){
			return;
		}
		else{
			
			if (apc_exists(self::$application_prefix)){
				$data= apc_fetch(self::$application_prefix);
			}
			else{
				$data= self::setConfig();
			}
			self::$conf = $data;
		}
		
	}
	
    static function connectToConfDB(){
		if(self::$database_type=='mongo'){
			$Connection = new WhMongo(self::$database_credentials);
			self::setMongo($Connection);
		}
	}
	
    static function  fetchConfigFromDB(){
		if(self::$database_type=='mongo'){

			$Connection = new WhMongo(self::$database_credentials);
			//$Connection = StaticCon::getMongoCon(self::$database_credentials);
			$Connection->setCollection(self::$application_prefix);
			$configFromDB=$Connection->getAllData();
			return $configFromDB;
		}
	}
	
	
	// this method will set all the config data fetched from the DB into a static variable that will be used later to get particular parameters ( like cms db credentials, solr api credentials etc) 
	
    static function setConfig(){
		if (!apc_exists(self::$application_prefix)){
			$data=self::fetchConfigFromDB();
			apc_add(self::$application_prefix,$data);
		}
		return apc_fetch(self::$application_prefix);
	}
	
	static function setMongo($Mongo){
		self::$Mongo=$Mongo;
	}
	
	static function getMongo(){
		return self::$Mongo;
	}
}
