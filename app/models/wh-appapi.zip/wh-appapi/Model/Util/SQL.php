<?php
namespace WH\Model\Util;
use WH\Model\Config\Config as Config;
use WH\Model\Core\Constants as C;

/*********

@TODO: Connection pool, other optimisation

*********/



class SQL
{
    var $db_debug               = FALSE;
    var $result_id              = NULL;
    var $result_array           = array();
    var $result_object          = array();
    var $num_rows               = 0;
    public $query_num           = 0;
    private $link_id            = NULL;

    var $ar_select				= array();
    var $ar_set                 = array();
	var $ar_distinct			= FALSE;
	var $ar_from				= NULL;
	var $ar_join				= NULL;
	var $ar_where				= array();
	var $ar_like				= array();
	var $ar_groupby				= array();
	var $ar_having				= array();
	var $ar_limit				= FALSE;
	var $ar_offset				= FALSE;
	var $ar_order				= FALSE;
	var $ar_orderby				= array();
	var $ar_wherein				= array();
    var $ar_store_array			= array();
    
    function  __construct($DBType='frontEndDB')
    {
        $this->$DBType();
    }
	
	function frontEndDB(){
		$dbConfig=Config::get('frontend');
		$this->connect($dbConfig['host'],$dbConfig['username'],$dbConfig['password'],$dbConfig['dbname']);
	}
	
	function CmsDB(){
		if(C::env()=='appapi')
			$dbConfig=Config::get('devcms');
		else if(C::env()=='qc')
			$dbConfig=Config::get('qccms');
		else if(C::env()=='content')
			$dbConfig=Config::get('contentcms');
		else if(C::env()=='staging')
			$dbConfig=Config::get('stagingcms');
		else
			$dbConfig=Config::get('devcms');
		
		$this->connect($dbConfig['host'],$dbConfig['username'],$dbConfig['password'],$dbConfig['dbname']);
	}
	
    public function connect($hostname,$username,$password,$database,$pconnect=0,$char_set='utf8', $collation='utf8_general_ci')
    {
        $this->link_id = $pconnect==0 ? @mysql_connect($hostname,$username,$password,true) : @mysql_pconnect($hostname,$username,$password);
       
	    if(@mysql_get_server_info($this->link_id)>'4.1'){
			mysql_query("SET NAMES '$char_set' COLLATE '$collation'", $this->link_id);
        }
        if(@mysql_get_server_info($this->link_id)){
            mysql_query("SET sql_mode=''",$this->link_id);
        }
        if($database){
            if(!@mysql_select_db($database, $this->link_id)){
                die("Cannot use database");
            }
        }
    }
    function debug()
    {
        $this->db_debug = TRUE;
    }
    function result($type = 'object')
	{
        return ($type == 'object') ? $this->result_object() : $this->result_array();
	}
    function result_object()
    {
        if(count($this->result_object) > 0)
        {
            $this->result_object = null;
        }
        if ($this->result_id === FALSE OR $this->num_rows() == 0)
        {
            return array();
        }
        $this->_data_seek(0);
        while ($row = mysql_fetch_object($this->result_id))
        {
            $this->result_object[] = $row;
        }
        return $this->result_object;
    }
    function result_array()
    {
        if(count($this->result_array) > 0){
            $this->result_array = null;
        }

        if ($this->result_id === FALSE OR $this->num_rows() == 0)
        {
            return array();
        }
        $this->_data_seek(0);
        while ($row = mysql_fetch_assoc($this->result_id))
        {
            $this->result_array[] = $row;
        }
        return $this->result_array;
    }
    
    function query($sql, $method='')
    {
        if($method=='ub' && function_exists('mysql_unbuffered_query')){
            $this->result_id = mysql_unbuffered_query($sql,$this->link_id);
        }else{
            $this->result_id = mysql_query($sql, $this->link_id);
        }
        $this->query_num++;
        if(!$this->result_id) die('Query Error : (--- '.$sql.' ---)');
        if($this->db_debug == TRUE){
            echo $sql;
        }
        return $this;
    }
    
    function num_rows()
    {
        return @mysql_num_rows($this->result_id);
    }
    
    function _data_seek($n = 0)
    {
        return mysql_data_seek($this->result_id, $n);
    }
   
    function select($select = '*')
    {
        
        if (is_string($select))
		{
			$select = explode(',', $select);
		}

		foreach ($select as $val)
		{
			$val = trim($val);

			if ($val != '')
			{
				$this->ar_select[] = $val;
			}
		}
        return $this;
    }
    
    function distinct($val = TRUE)
	{
		$this->ar_distinct = (is_bool($val)) ? $val : TRUE;
		return $this;
	}
    
    function from($from)
    {
        $this->ar_from = $from;
        return $this;
    }
    //JOIN，join('table2', 'table1.id = table2.id', 'left')
    function join($table, $cond, $type = '')
    {
        if ($type != '')
		{
			$type = strtoupper(trim($type));

			if ( ! in_array($type, array('LEFT', 'RIGHT', 'OUTER', 'INNER', 'LEFT OUTER', 'RIGHT OUTER')))
			{
				$type = '';
			}
			else
			{
				$type .= ' ';
			}
		}

        // Assemble the JOIN statement
		$join = $type.'JOIN '.$table.' ON '.$cond;

		$this->ar_join = $join;

		return $this;
    }
    
    function where($key, $value = NULL)
    {
        return $this->_where($key, $value, 'AND ');
    }
    function or_where($key, $value = NULL)
	{
		return $this->_where($key, $value, 'OR ');
	}
    function orwhere($key, $value = NULL)
	{
		return $this->or_where($key, $value);
	}
    function _where($key, $value = NULL, $type = 'AND ', $escape = NULL)
	{
        
		if ( ! is_array($key))
		{
			$key = array($key => $value);
		}

		foreach ($key as $k => $v)
		{
			$prefix = (count($this->ar_where) == 0) ? '' : $type;
			$this->ar_where[] = $prefix.$k.'='."'$v'";
		}

		return $this;
	}
    
    function limit($value, $offset = '')
	{
		$this->ar_limit = $value;

		if ($offset != '')
		{
			$this->ar_offset = $offset;
		}

		return $this;
	}
    function _limit($sql, $limit, $offset)
	{
		if ($offset == 0)
		{
			$offset = '';
		}
		else
		{
			$offset .= ", ";
		}

		return $sql."LIMIT ".$offset.$limit;
	}
    function offset($offset)
	{
		$this->ar_offset = $offset;
		return $this;
	}
    function set($key, $value = '')
	{
		if ( ! is_array($key))
		{
			$key = array($key => $value);
		}

		foreach ($key as $k => $v)
		{
			$this->ar_set[$k] = $v;
		}

		return $this;
	}
    //
	function get($table = '', $limit = null, $offset = null)
    {
        if ($table != '')
		{
			$this->from($table);
		}

		if ( ! is_null($limit))
		{
			$this->limit($limit, $offset);
		}

		$sql = $this->_compile_select();
		$this->query($sql);
		$this->_reset_select();
		return $this;
    }
    
    function _compile_select()
    {
        
        $sql = ( ! $this->ar_distinct) ? 'SELECT ' : 'SELECT DISTINCT ';//distinct去掉重复的

        if (count($this->ar_select) == 0)
        {
            $sql .= '*';
        }
        else
        {
            foreach ($this->ar_select as $key => $val)
            {
                $this->ar_select[$key] = $val;
            }

            $sql .= implode(', ', $this->ar_select);
        }
        
        if (count($this->ar_from) > 0)
		{
			$sql .= "\nFROM ";

			$sql .= $this->ar_from;
		}
        
        if (count($this->ar_join) > 0)
		{
			$sql .= "\n";

			$sql .= $this->ar_join;
		}
        
        if (count($this->ar_where) > 0 OR count($this->ar_like) > 0)
		{
			$sql .= "\n";

			$sql .= "WHERE ";
		}
        if (count($this->ar_like) > 0)
		{
			if (count($this->ar_where) > 0)
			{
				$sql .= "\nAND ";
			}

			$sql .= implode("\n", $this->ar_like);
		}
        
		$sql .= implode("\n", $this->ar_where);
        
        if (is_numeric($this->ar_limit))
		{
			$sql .= "\n";
			$sql .= "LIMIT $this->ar_limit";
            if($this->ar_offset != ''){
                $sql .= " , $this->ar_offset";
            }
		}
        return $sql;
    }
    
    function delete($table = '', $where = '', $limit = NULL, $reset_data = TRUE)
    {
        if($table == ''){
            die("db must set table");
        }
        
        if ($where != '')
		{
			$this->where($where);
		}
        
        if (count($this->ar_where) > 0 OR count($this->ar_like) > 0)
        {
            $sql .= "\n";

            $sql .= "WHERE ";
        }
        $sql .= implode("\n", $this->ar_where);

        if (count($this->ar_where) == 0 && count($this->ar_wherein) == 0 && count($this->ar_like))
		{
			if ($this->db_debug)
			{
				die('db del must use where');
            }
		}
        
        if ($limit != NULL)
		{
			$this->limit($limit);
		}
       
        if (is_numeric($this->ar_limit))
		{
			$sql .= "\n";
			$sql .= "LIMIT $this->ar_limit";
            if($this->ar_offset != ''){
                $sql .= " , $this->ar_offset";
            }
		}

        $sql = $this->_delete($table, $this->ar_where, $this->ar_like, $this->ar_limit);

		$this->_reset_write();

		$this->query($sql);
        return mysql_affected_rows($this->link_id);
    }
    function empty_table($table = '')
    {
        if($table == ''){
            die("db must set table");
        }

        $sql = $this->_delete($table);

        $this->_reset_write();

        $this->query($sql);
        return mysql_affected_rows($this->link_id);
    }
    function _delete($table, $where = array(), $like = array(), $limit = FALSE)
	{
		$conditions = '';

		if (count($where) > 0 OR count($like) > 0)
		{
			$conditions = "\nWHERE ";
			$conditions .= implode("\n", $this->ar_where);

			if (count($where) > 0 && count($like) > 0)
			{
				$conditions .= " AND ";
			}
			$conditions .= implode("\n", $like);
		}

		$limit = ( ! $limit) ? '' : ' LIMIT '.$limit;

		return "DELETE FROM ".$table.$conditions.$limit;
	}
    
    function truncate($table = '')
    {
        if($table == ''){
            die("db must set table");
        }

        $sql = $this->_truncate($table);

		$this->_reset_write();

		return $this->query($sql);
    }
    function _truncate($table)
	{
		return "TRUNCATE ".$table;
	}
    
    function insert($table = '', $set = NULL)
	{
        if($table == ''){
            die("db must set table");
        }

        
		if ( ! is_null($set))
		{
			$this->set($set);
		}

		if (count($this->ar_set) == 0)
		{
            die ("db must use set");
		}
        $sql = $this->_insert($table, array_keys($this->ar_set), array_values($this->ar_set));
		$this->_reset_write();
        return $this->query($sql);
        
	}
    function _insert($table, $keys, $values)
	{
		return "INSERT INTO ".$table." (".implode(', ', $keys).") VALUES ('" . implode("', '", $values) . "')";
	}
    function insert_id()
    {
        return @mysql_insert_id($this->link_id);
    }
    function version()
	{
        $version = $this->query("SELECT version() AS version")->result();
        return $version[0]->version;
	}
    
    function update($table = '', $set = NULL, $where = NULL, $limit = NULL)
    {
         $sql='';
		if ( ! is_null($set))
		{
			$this->set($set);
		}

		if (count($this->ar_set) == 0)
		{
            die ("db must use set");
		}

        
        if ($where != '')
		{
			$this->where($where);
		}

        if (count($this->ar_where) > 0 OR count($this->ar_like) > 0)
        {
            $sql .= "\n";

            $sql .= "WHERE ";
        }
        $sql .= implode("\n", $this->ar_where);
        
        
        if ($limit != NULL)
		{
			$this->limit($limit);
		}
        
        if (is_numeric($this->ar_limit))
		{
			$sql .= "\n";
			$sql .= "LIMIT $this->ar_limit";
            if($this->ar_offset != ''){
                $sql .= " , $this->ar_offset";
            }
		}

        $sql = $this->_update($table, $this->ar_set, $this->ar_where, $this->ar_orderby, $this->ar_limit);
        $this->_reset_write();
        $this->query($sql);
        return mysql_affected_rows($this->link_id);
    }
    function _update($table, $values, $where, $orderby = array(), $limit = FALSE)
	{
		foreach($values as $key => $val)
		{
			$valstr[] = $key." = "."'$val'";
		}

		$limit = ( ! $limit) ? '' : ' LIMIT '.$limit;

		$orderby = (count($orderby) >= 1)?' ORDER BY '.implode(", ", $orderby):'';

		$sql = "UPDATE ".$table." SET ".implode(', ', $valstr);

		$sql .= ($where != '' AND count($where) >=1) ? " WHERE ".implode(" ", $where) : '';

		$sql .= $orderby.$limit;

		return $sql;
	}
    
    function _reset_run($ar_reset_items)
	{
		foreach ($ar_reset_items as $item => $default_value)
		{
			if ( ! in_array($item, $this->ar_store_array))
			{
				$this->$item = $default_value;
			}
		}
	}
    
	function _reset_select()
	{
		$ar_reset_items = array(
                            'debug'             => FALSE,
                            'ar_select'			=> array(),
                            'ar_from'			=> array(),
                            'ar_join'			=> array(),
                            'ar_where'			=> array(),
                            'ar_like'			=> array(),
                            'ar_groupby'		=> array(),
                            'ar_having'			=> array(),
                            'ar_orderby'		=> array(),
                            'ar_wherein'		=> array(),
                            'ar_distinct'		=> FALSE,
                            'ar_limit'			=> FALSE,
                            'ar_offset'			=> FALSE,
                            'ar_order'			=> FALSE,
                        );

		$this->_reset_run($ar_reset_items);
	}
    
	function _reset_write()
	{
		$ar_reset_items = array(
                            'ar_set'		=> array(),
                            'ar_from'		=> array(),
                            'ar_where'		=> array(),
                            'ar_like'		=> array(),
                            'ar_orderby'	=> array(),
                            'ar_limit'		=> FALSE,
                            'ar_order'		=> FALSE
                            );

		$this->_reset_run($ar_reset_items);
	}
    public function free_result()
    {
        $void = func_get_args(); 
        foreach($void as $query){
        
            if(is_resource($query) && get_resource_type($query) === 'mysql result'){
                return mysql_free_result($query);
                $this->result_id = FALSE;
            }
        }
    }
    protected function close()
    {
        return @mysql_close($this->link_id);
    }

    public function  __destruct()
    {
        $this->free_result();
    }
}
?>
