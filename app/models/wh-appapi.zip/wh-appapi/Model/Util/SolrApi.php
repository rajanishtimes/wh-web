<?php

/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
namespace WH\Model\Util;

use WH\Api\Api;
use WH\Model\Util\Curl;
use WH\Model\Core\Constants as C;
use WH\Model\Core\Config;
use WH\Model\SolrLogs;
class SolrApi{
	
    private $params = array();
    private $response;
    private $matchCount = 0;
    private $results = array();
    private $facets = array();
    
	public function setApiType($type){
        $this->ApiType = $type;
    }
    
    public function getApiType(){
        return $this->ApiType;
    }   
    
    public function setResultType($type){
        $this->ResultType = $type;
    }
    
    public function getResultType(){
        return $this->ResultType;
    }  
    
    function setMeta($name, $value){
        if($name && $value){
            $this->meta[$name] = $value;
        }
    }
    function getMeta(){
		if(isset( $this->meta))
        return $this->meta;
    }
    public function setParam($name, $value){
        if($name && $value){
            $this->params[$name] = $value;
        }
    }
     
    function setParams($params){
        if($params){
            $this->params = $params;
        }
    }
    
    private function getParams(){
        return $this->params;
    }
    
    public function call(){
		SolrLogs::setPreSolrTime(microtime(true)*1000);
        $retVal = Curl::get(Config::get('solrEndpoint').$this->getApiType(), $this->getParams());
		SolrLogs::setPostSolrTime(microtime(true)*1000);
		$response = json_decode($retVal, TRUE);
        $this->setResponse($response);
        $this->parseResponse();
    }
    
    private function parseResponse(){
        $this->processResponseHeader();
        $this->processResponseBody();
    }
    
	private function processAutosuggestResult($pre_results){
		$results=array();
		if(isset($pre_results['searchresult']))
			$pre_results=$pre_results['searchresult'];
		if(!empty($pre_results)){		
			foreach($pre_results as $result){	
				$results[]=$result['suggestion'];
			} 
		}
		return $results;
	} 
	
    private function processResponseBody(){
        $fullResponse = $this->getResponse();
		
		if(isset($fullResponse['numFound']))
			$this->setMatchCount($fullResponse['numFound']);

		if(isset($fullResponse['body']))
			$fullResponse = $fullResponse['body'];
	
		if(isset($fullResponse['searchResult']))
			$responseForSponsored=$fullResponse = $fullResponse['searchResult'];
		
		if(isset($fullResponse['matches']))
			$this->setMatchCount($fullResponse['matches']);
		
		$finalresponse = isSet($fullResponse['docs']) ? $fullResponse['docs'] : $fullResponse;
		
		$resultType=$this->getResultType();
		$results = $this->$resultType($finalresponse);
		
		//Processing sponsored data in case of SearchEntity
		
		if($this->getSolrType()=='search'){
			$results=$this->processSponsoredResponse($responseForSponsored,$results);
		}
		if(isset($fullResponse['facet']))
			$this->setFacet($fullResponse['facet']);
	
		$this->setResults($results);
    }
    
    private function processResponseHeader(){
        $response = $this->getResponse();
        $respHeader = $response['header'];
		if(isset($respHeader['responseTime']))
		SolrLogs::setResponseTime($respHeader['responseTime']);
    }
    
	private function processSponsoredData($responseForSponsored){
		$sponsoredFinal=array();
		if(isset($responseForSponsored['sponsored'])){
			if(isset($responseForSponsored['sponsored']['docs'])){
				$sponsoredData=$responseForSponsored['sponsored']['docs'];
				if(!empty($sponsoredData)){
					foreach($sponsoredData as $sponsored){
						$sponsoredFinal[$sponsored['sponsored_position']] = $this->processSummary($sponsored['summary']);
						$sponsoredFinal[$sponsored['sponsored_position']]['label']='sponsored';
					}
				}
			}
		}
		return $sponsoredFinal;
	}
	
	private function processSponsoredResponse($responseForSponsored,$results){
		$sponsoredIDs=array();
		$sponsoredArray=$this->processSponsoredData($responseForSponsored);
		
		if(!empty($results)){
			foreach($results as $i=>$indivRecord){
				if(!empty($sponsoredArray)){
					foreach($sponsoredArray as $j=>$rslt){
						if($rslt['id']==$indivRecord['id']){
								unset($results[$i]);
						}
					}
				}
			}
			$results = array_values($results);
		}
		
		if(!empty($sponsoredArray)){
			ksort($sponsoredArray);
			foreach($sponsoredArray as $i=>$res){
				$sponsoredIDs[]=$res['id'];
				$insertArr[$i]=$res;
				array_splice($results, $i, 0, $insertArr);
				unset($insertArr[$i]);						
			}
		}
		
		return $results;
	}
	
    private function setResponse($response){
        $this->response = $response;
    }
    
    private function getResponse(){
        return $this->response;
    }
    
    private function setResults($results){
        $this->results = $results;
    }
    
    public function getResults(){
        return $this->results;
    }
      
    public function setSolrType($SolrType){
        $this->SolrType = $SolrType;
    }
    
    private function getSolrType(){
		if(isset($this->SolrType))
			return $this->SolrType;
		else
			return '';
    }
	
    private function setMatchCount($num){
        $this->matchCount = $num;
    }
    
    public function getMatchCount(){
        return $this->matchCount;
    }
    
    private function setFacet($facet){
        $this->facets = $facet;
    }
    
    public function getFacets(){
        return $this->facets;
    }
    
    private function processSearchResult($results){
		
        $final = array();
		if(!empty($results)){
			
        foreach($results as $res){
			
            if(isSet($res['summary'])){
                $tuple = $this->processSummary($res['summary']);
            }
			else if(isSet($res['detail'])){	
                $tuple = $this->processDetail($res['detail']);
            }
			else{
                $tuple = $res;
            }
            $final[] = $tuple;
        }
	}
        return $final;
    }
    
    private function processSummary($summary){
        $tuple = array();
        $summary = json_decode(str_replace(array("\n","\r\n", "\r", '\n', '<br/>' , '\s' , '\t'), '', $summary), true);
		$tuple['id'] = isSet($summary['id']) ? (string) $summary['id'] : '0';
        $tuple['title'] = isSet($summary['title']) ? $summary['title'] : '';
        
        $tuple['type'] = isSet($summary['type']) ? strtoupper($summary['type']) : 'EVENT';
        if($tuple['type'] == 'EVENT'){
            $venue = $this->extractVenue($summary);
            $time = $this->extractEventTime($summary);
            $tuple['venue'] = $venue['formatted_address'];
            $tuple['time'] = implode(', ', $time) ;
			$start_time='';
			$end_time='';
			
			if(isSet($summary['start_date']) && isSet($summary['start_time'])){
				$start_time=$summary['start_date'].' '.$summary['start_time'];
				$start_time=strtotime($start_time);
			}
			if(isSet($summary['end_date']) && isSet($summary['end_time'])){
				$end_time=$summary['end_date'].' '.$summary['end_time'];
				$end_time=strtotime($end_time);
			}
			$tuple['start_time']=$start_time;
			$tuple['end_time']=$end_time;
        }
        
        $tuple['label'] = isSet($summary['label']) ? $tuple['label'] : '';

        $tuple['category'] = isSet($summary['categories']) ? $summary['categories'] : [];
		
        $tuple['image'] = array('uri'=>'','x'=>0,'y'=>0,'h'=>0,'w'=>0);
		
		$tuple['url'] = isSet($detail['url']) ? $detail['url'] : '';
		
		if(isset($summary['images']))
			$imagesArr=$summary['images'];
		else if (isset($summary['image']))
			$imagesArr=$summary['image'];
		if(isSet($imagesArr) && !empty($imagesArr)){
			if(isset($imagesArr[0]))
			$allImages=$imagesArr[0];
		
			$cover_image=0;
			
			if(!empty($allImages)){
				foreach($allImages as $i=>$indivImage){	
					if($indivImage['is_cover']==1)
						$cover_image=$i;
				}
			}
		
			if(isset($allImages[$cover_image]))
			$summary['image']=$allImages[$cover_image];
		
			if(isset($summary['image']['uri'])){
				$imageDetail=array('uri'=>$summary['image']['uri'],'x'=>0,'y'=>0,'h'=>0,'w'=>0);
				if(isset($summary['image']['cropdata']) && $summary['image']['cropdata']!=''){
					$image_Data=json_decode($summary['image']['cropdata']);
					$imageDetail=array('uri'=>$summary['image']['uri'],'x'=>$image_Data->img_data->x,'y'=>$image_Data->img_data->y,'h'=>$image_Data->img_data->height,'w'=>$image_Data->img_data->width);
				}
				
				if(isset($summary['image']['uri']))
					$tuple['image']=$imageDetail;
			}
		}
		
        $description = isset($summary['description']) && !is_null($summary['description']) ? strip_tags($summary['description']) : '';
        if(strlen($description) > 100){
            $description = substr($description, 0, 96) . ' ...';
        }
	//if($description!='')
		
        $tuple['description'] = trim($description);
		
		if($tuple['type'] == 'CONTENT'){
			$published_time = isset($summary['published_time']) ? $summary['published_time'] : '';
			$tuple['published_time']=$published_time;
		}
		
        return $tuple;
    }
    
    private function processDetail($detail){
		$tuple = array();
        $detail = json_decode($detail, true);
		$type = isSet($detail['type']) ? strtoupper($detail['type']) : 'EVENT';
       
        $tuple['title'] = $detail['title'];
        $tuple['type'] = $type;
        $tuple['categories'] = isSet($detail['categories']) ? (array)$detail['categories'] : [];
        $albumImages[] =array('uri'=>'','x'=>0,'y'=>0,'h'=>0,'w'=>0,'is_cover'=>0);
		$imagesArr=array();
		if(isset($detail['images']))
			$imagesArr=$detail['images'];
		else if (isset($detail['image']))
			$imagesArr=$detail['image'];
		if(isSet($imagesArr) && !empty($imagesArr)){
			if(isSet($imagesArr[0])){
				$allImages=$imagesArr[0];
				$albumImages=array();
				if(!empty($allImages)){
					foreach($allImages as $i=>$indivImage){	
						$imageDetail['uri']=$indivImage['uri'];
						$imageDetail=array('uri'=>$indivImage['uri'],'x'=>0,'y'=>0,'h'=>0,'w'=>0,'is_cover'=>$indivImage['is_cover']);
						if(isset($indivImage['cropdata']) && $indivImage['cropdata']!=''){
							$image_Data=json_decode($indivImage['cropdata']);
							$imageDetail=array('uri'=>$indivImage['uri'],'x'=>$image_Data->img_data->x,'y'=>$image_Data->img_data->y,'h'=>$image_Data->img_data->height,'w'=>$image_Data->img_data->width,'is_cover'=>$indivImage['is_cover']);
						}
						$albumImages[]=$imageDetail;
					}
				}
			}
		}
        $tuple['images']=$albumImages;
		$tuple['page_title'] = isSet($detail['page_title']) ? $detail['page_title'] : '';
		$tuple['url'] = isSet($detail['url']) ? $detail['url'] : '';
		$tuple['meta_description'] = isSet($detail['meta_description']) ? $detail['meta_description'] : '';
		$tuple['meta_keywords'] = isSet($detail['meta_keywords']) ? $detail['meta_keywords'] : '';
		$tuple['og_title'] = isSet($detail['og_title']) ? $detail['og_title'] : '';
		$tuple['og_description'] = isSet($detail['og_description']) ? $detail['og_description'] : '';
		$tuple['og_image'] = isSet($detail['og_image']) ? $detail['og_image'] : '';
		$tuple['deep_link'] = isSet($detail['deep_link']) ? $detail['deep_link'] : '';
		
        if($type == 'EVENT'){
			
            $tuple['venue'] = $this->extractVenue($detail);
			$tuple['time'] = $this->extractEventTime($detail);
			$start_time='';
			$end_time='';
			
			if(isSet($detail['start_date']) && isSet($detail['start_time'])){
				$start_time=$detail['start_date'].' '.$detail['start_time'];
				$start_time=strtotime($start_time);
			}
			if(isSet($detail['end_date']) && isSet($detail['end_time'])){
				$end_time=$detail['end_date'].' '.$detail['end_time'];
				$end_time=strtotime($end_time);
			}
			$tuple['start_time']=$start_time;
			$tuple['end_time']=$end_time;
        }else if($type == 'VENUE'){
			$tuple['address'] = isSet($detail['address']) ? $detail['address'] : '';
			$tuple['categories'] = isSet($detail['tags']) ? (array)$detail['tags'] : [];
			$tuple['address'] = isSet($detail['locality']) ? $detail['locality'] : '';
			$tuple['landmark'] = isSet($detail['landmark']) ? $detail['landmark'] : '';
			$tuple['checkin'] = isSet($detail['checkin']) ? $detail['checkin'] : '';
			$tuple['checkout'] = isSet($detail['checkout']) ? $detail['checkout'] : '';
			$tuple['phonedata'] = isSet($detail['phonedata']) ? (array)$detail['phonedata'] : [];
			$tuple['mobiledata'] = isSet($detail['mobiledata']) ? (array)$detail['mobiledata'] : [];
			$tuple['contact'] = isSet($detail['contact']) ? $detail['contact'] : '';
			$tuple['emailvenue'] = isSet($detail['emailvenue']) ? $detail['emailvenue'] : '';
			$tuple['facebook_url'] = isSet($detail['facebook_url']) ? $detail['facebook_url'] : '';
			$tuple['website'] = isSet($detail['facebook_url']) ? $detail['website'] : '';
			$tuple['latitude'] = isSet($detail['latitude']) ? $detail['latitude'] : '';
			
			$tuple['events'] = $this->extractEvents($detail);
		}else{
				$author = array();
				$author['id'] = '';
				$author['name'] = '';
				$author['bio'] = '';
				$author['image_url'] = '';
					
				if(isset($detail['author_id']) && $detail['author_id']!='')
					$author['id']=$detail['author_id'];
				
				if(isset($detail['author_name']) && $detail['author_name']!='')
					$author['name']=$detail['author_name'];
				
				if(isset($detail['author_bio']) && $detail['author_bio']!='')
					$author['bio']=$detail['author_bio'];
				
				if(isset($detail['author_image']['images'][0][0]['uri']) && $detail['author_image']['images'][0][0]['uri']!='')
					$author['image_url']=$detail['author_image']['images'][0][0]['uri'];
				
				$tuple['author'] = $author;
				if(isSet($detail['time'])){
					$tuple['time'] = date('jS M, Y', strtotime($detail['time']));
				}
				$summary='';
				if(isset($detail['summary'])){
					$summary=$detail['summary'];
				}
				
				$tuple['summary']=$summary;
		}   
		if(isset($detail['tags']) && !empty($detail['tags']))
			$tuple['tags']=explode(',',$detail['tags']);
		else
			$tuple['tags']=null;
        $tuple['description'] = isset($detail['content']) ? $detail['content'] : ( isSet($detail['description']) ? $detail['description'] : '');
		return $tuple;
        
    }
	
   
    private function extractEventTime($detail){
        $tuple = array();
        if(isSet($detail['start_date']) && isSet($detail['start_time'])){
            $dates = date('jS M', strtotime($detail['start_date'])); 
            if(isSet($detail['end_date']) && $detail['start_date']!=$detail['end_date']) 
                $dates .=  ' - ' . date('jS M', strtotime($detail['end_date']));
			
			if(isset($detail['eventtype']) && isset($detail['weekdaysdata'])){
				if($detail['eventtype']=='Selective Days'){
					$weekDays=array(1=>'M',2=>'T',3=>'W',4=>'Th',5=>'F',6=>'Sa',7=>'Su');
					if(!empty($detail['weekdaysdata'])){
						$weekDaysArr=array();
						foreach($detail['weekdaysdata'] as $weekdayData){
							$weekDaysArr[]=$weekDays[$weekdayData];
						}
						if(!empty($weekDaysArr)){
							$dates.=' ('.implode(', ',$weekDaysArr).')';
						}
					}
				}
			}
			
			
            $tuple['short'] = $dates;
            $start_hrs = $detail['start_time'] ;
            if(strlen($start_hrs) == 2){
                $start_hrs .= '00';
            }
            $end_hrs = $detail['end_time'] ;
            if(strlen($end_hrs) == 2){
                $end_hrs .= '00';
            }
            $time = date('h:ia', strtotime('2014-01-01 '.$start_hrs)) . ' - '. date('h:ia', strtotime('2014-01-01 '.$end_hrs));
            $tuple['long'] = $time;
            
        }else{
            //throw new \Exception("Timings not available",2);
        }
        return $tuple;
    }
    
    private function extractVenue($detail){
        $venue = array();
            $venue['lat'] = (float) 0.0;
            $venue['lng'] = (float) 0.0;
            $venue['name'] = '';
            $venue['formatted_address'] = '';
            if(isSet($detail['venue'])){
                $venueData = $detail['venue'];
                if(isSet($venueData[0])){
                    $v = $venueData[0];
					$venue['id'] = $v['id'];
                    $venue['lat'] = isSet($v['latitude']) ? $v['latitude'] : 0.0;
                    $venue['lng'] = isSet($v['longitude']) ? $v['longitude'] : 0.0;
                    $venue['name'] = isSet($v['name']) ? $v['name'] : '';
                    $formatted_address = '';
                    $contactDetail = '';
                    if(isSet($v['address']) && trim($v['address'])!=''){
                        $address_arr[] = $v['address'];
                    }
                    if(isSet($v['landmark']) && trim($v['landmark'])!=''){
                        $address_arr[] = $v['landmark'];
                    }
                    if(isSet($v['localityname']) && trim($v['localityname'])!=''){
                        $address_arr[] = $v['localityname'];
                    }
                    if(isSet($v['cityname']) && trim($v['cityname'])!=''){
                        $address_arr[] = $v['cityname'];
                    }
                    $formatted_address = implode(', ', $address_arr);
                    $venue['formatted_address'] = $formatted_address;
					if(!empty($v['phonedata']))
						$contact[]=implode(', ',$v['phonedata']);
					
					if(!empty($v['mobiledata']))
						$contact[]=implode(', ',$v['mobiledata']);
					
					if(!empty($contact))
						$contactDetail=implode(', ',$contact);
					
                    $venue['contact'] = $contactDetail; 
                }
            }
            return $venue;
    }
	
	/* Code added for get events based on venue */
	private function extractEvents($detail){
		
	}
	
    private function processEventDetail(){
        
    }
    
    private function processContentDetail(){
        
    }
    
    public function processEntityResult($result){
        return $results[0];
    }
	
	public function processCategoryCountResult(){
		$retVal = Curl::get(Config::get('solrEndpoint').$this->getApiType(), $this->getParams());
		$response = json_decode($retVal, TRUE);
		$count=array();
		if(isset($response['body'])){
			$response=$response['body'];
			if(isset($response['searchResult']))
				$response=$response['searchResult'];
			
			if(isset($response['facet']))
				$response=$response['facet'];
				
			if(isset($response['facetMap']))
				$response=$response['facetMap'];
			
			if(isset($response['category_ft'])){
				$countArr=$response['category_ft'];
				$allCatId=C::getCategories();
				if(!empty($allCatId)){
					$j=0;
					foreach($allCatId as $i=>$cat){
						if(!array_key_exists($cat,$countArr)){
							$count[$j]['category_id']=$i;
							$count[$j]['count']=0;
						}else{
							$count[$j]['category_id']=$i;
							$count[$j]['count']=$countArr[$cat];
						}
						$j++;
					}
				}
			}
		}
		return $count;
	}
}
