<?php

/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
namespace WH\Model\Util;

use WH\Model\Util\Curl;
use WH\Model\Core\Constants as C;
use WH\Model\Core\Config;

class CmsApi{
	
   
    // Params
    private $params = array();
	
    // Response components
    private $response;
    private $matchCount = 0;
    private $results = array();
    private $facets = array();
    
    public function setApiType($type){
        $this->ApiType = $type;
    }
    
    public function getApiType(){
        return $this->ApiType;
    }   
    
    public function setResultType($type){
        $this->ResultType = $type;
    }
    
    public function getResultType(){
        return $this->ResultType;
    }  
	
    public function setParam($name, $value){
        if($name && $value){
            $this->params[$name] = $value;
        }
    }
    
    private function getParams(){
		if(isset($this->params) && !empty($this->params))
        return $this->params;
    }
    
    function setParams($params){
        if($params){
            $this->params = $params;
        }
    }
    
    public function call(){
		$apiType=$this->getApiType();
		$this->setParam('format', 'json');
        $retVal = Curl::get(Config::get('cmsEndpoint').$apiType, $this->getParams(),true);    
    	$response = json_decode($retVal, TRUE);
    
        $this->setResponse($response);
        $this->parseResponse();
    }
   
    public function callpost(){
		$apiType=$this->getApiType();
		$this->setParam('format', 'json');
        $retVal = Curl::get(Config::get('cmsEndpoint').$apiType, $this->getParams(),true,true);    
        $response = json_decode($retVal, TRUE);
		$this->setResponse($response);
        $this->parseResponse();
    }
   
    private function parseResponse(){
        $this->processResponseBody();
    }
   
    private function processResponseBody(){
        $response = $this->getResponse(); 
		$results = $this->processResults($response);
		$this->setResults($results);
    }
    
    private function setResponse($response){
        $this->response = $response;
    }
    
    private function getResponse(){
        return $this->response;
    }
    
    private function setResults($results){
        $this->results = $results;
    }
    
    public function getResults(){
        return $this->results;
    }
    
    private function setMatchCount($num){
        $this->matchCount = $num;
    }
    
    public function getMatchCount(){
        return $this->matchCount;
    }
    
    private function setFacet($facet){
        $this->facets = $facet;
    }
    
    public function getFacets(){
        return $this->facets;
    }
    
    private function processResults($results){
		$final = array();
		if(!empty($results)){
			$resultType=$this->getResultType();
			if (((count($results) == count($results, COUNT_RECURSIVE)) || count($results)==1) || !isset($results[0])){
				$final=$this->$resultType($results);
			}
			else
			{
				foreach($results as $res){
					$tuple = $this->$resultType($res);
					$final[] = $tuple;
				} 
			} 
		}
        return $final;
    }
    
    private function processCity($detail){
        $tuple = array();
		$tuple['id'] = "$detail[id]";
		$tuple['name'] = $detail['name'];
        $tuple['image_url'] = isSet($detail['image']) ? strtoupper($detail['image']) : '';
        return $tuple; 
    } 
    private function processQuestion($detail){
        return $detail; 
    } 
    private function processCategory($detail){
        $tuple = array();
		$tuple['id'] = "$detail[id]";
		$tuple['name'] = $detail['name'];
        $tuple['image_url'] = isSet($detail['image']) ? strtoupper($detail['image']) : '';
        return $tuple;
    }
	
    private function processProfile($detail){
        $tuple = array();
		$tuple['id'] = $detail['id'];
		$tuple['name'] = $detail['user_name'];
		$image_url='';
        $first_name = isSet($detail['first_name']) ? strtoupper($detail['first_name']) : '';
        $last_name = isSet($detail['last_name']) ? strtoupper($detail['last_name']) : '';
        $tuple['full_name'] = $first_name.' '.$last_name;
        $tuple['description'] = isSet($detail['detail']) ? strtoupper($detail['detail']) : '';
        $tuple['type'] = isSet($detail['usertype']) ? strtoupper($detail['usertype']) : '';
        $tuple['city_id'] = isSet($detail['city_id']) ? strtoupper($detail['city_id']) : 0;
		
		if(isset($detail['media']['images'][0][0]['uri']))
			$image_url=$detail['media']['images'][0][0]['uri'];
		
		$tuple['image_url']=$image_url;
		
        $tuple['google_url'] = isSet($detail['google_url']) ? strtoupper($detail['google_url']) : '';
        $tuple['fb_url'] = isSet($detail['facebook_url']) ? strtoupper($detail['facebook_url']) : '';
        $tuple['twitter_url'] = isSet($detail['twitter_handle']) ? strtoupper($detail['twitter_handle']) : '';
        return $tuple;
    }
	
    private function processPosts($detail){
		$detail=$detail[0];
		$result=array();
		$result['total_count']=$detail['countRecords'];
		$contentList=array();
		if(!empty($detail['result'])){
			foreach($detail['result'] as $detailData){
				$contentList[]=$this->processPostIndiv($detailData);
			}
		}
		$result['contents']=$contentList;
		return $result;
    }
	
	private function processPostIndiv($result){
        $tuple = array();
		$tuple['id'] = $result['id'];
		$tuple['title'] = $result['title'];
		if($result['cover_image']!='')
			$tuple['cover_image'] = $result['cover_image'];
		else
			$tuple['cover_image'] = '';
		$tuple['published_on'] = date('jS M, Y',strtotime($result['published_on']));
        return $tuple;
	}
}
