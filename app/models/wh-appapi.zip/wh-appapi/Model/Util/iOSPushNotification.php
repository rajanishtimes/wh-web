<?php

namespace WH\Model\Util;
class iOSPushNotification {
	
	function send($deviceToken,$message,$uKey,$data=false){
		$success=0;
		$passphrase = 'whatshot';
		$ctx = stream_context_create();
		stream_context_set_option($ctx, 'ssl', 'local_cert', dirname(__FILE__).'/aps_development.pem');
		stream_context_set_option($ctx, 'ssl', 'passphrase', $passphrase);
	
	$fp =@stream_socket_client('ssl://gateway.sandbox.push.apple.com:2195', $err,$errstr, 60, STREAM_CLIENT_CONNECT|STREAM_CLIENT_PERSISTENT, $ctx);
		if (!$fp)
			$this->error("Unable to connect");
		
		$body['aps']['nav_url'] = 'timescity%3A%2F%2Fty%3Ds%26qu%3Dfood%26ci%3D0%26ca%3D2%26ti%3Dtoday';
		$body['aps']['icon'] = 'default';
		$body['aps']['title'] = "what's hot";
		$body['aps']['desc'] = $message;
		$body['aps']['key'] = $uKey;
		$body['aps']['in_app'] = 'true';
		$body['aps']['show'] =1;
		
		if($data && !empty($data)){
			foreach ($data as $key => $value) {
				$body['aps'][$key] = $value;
			}
		}
		
		$body['aps']['alert'] = $message;
		$body['aps']['sound'] = 'default';
		$payload = json_encode($body);
		$msg = chr(0) . pack('n', 32) . pack('H*', $deviceToken) . pack('n', strlen($payload)) . $payload;
		$result = fwrite($fp, $msg, strlen($msg));
		if (!$result){
			$return['success']=0;
			$return['Message']='Failed sending notification';
		}
		else{
			$return['success']=1;
			$return['Message']='Notification has been sent successfully!';
		}
		fclose($fp);
		
		return $return;
	}
	
	function error($msg){
		throw new \Exception("iOS send notification failed with error:".$msg,1); 
	}
}
