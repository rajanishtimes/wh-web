<?php

namespace WH\Model\Util;
use WH\Model\Util\SQL;

class StaticCon{
	
	static $mysql_cons = array();
	static $mongo_cons = array();
	
	static function getMySqlCon($conf_name=''){
		if(isSet(self::$mysql_cons[$conf_name])){
			return self::$mysql_cons[$conf_name];
		}
		
		$Sql = new SQL($conf_name);
		self::$mysql_cons[$conf_name] = $Sql;
		return $Sql;
	}
}

?>