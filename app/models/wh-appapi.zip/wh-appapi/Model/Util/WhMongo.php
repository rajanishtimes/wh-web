<?php

namespace WH\Model\Util;
use WH\Model\Config\Config as Config;
use MongoClient;
use Mongo;
use MongoCollection;
use Exception;

class WhMongo
{

    const VERSION = '1.1';
    static public $con = array();
    private $server_name = null;
    public $db = null;
    public $coll = null;
    public $data = null;
    public $server = null;
    public $server2 = null;
    public $port = '27018';
    public $save = false;
	public $repset = 'tc0';
	public $username = '';
	public $password = '';
	public $readPreference = 'secondaryPreferred';
    public $read_tag = "";
    public $read_tag_pref = "";
    public $default_config = array(
            'db',
            'coll',
            'server',
            'port',
            'con',
            'save'
        );
    
    function __construct( $config = 'default_mongo',$params=array()) {
		$this->setParams($params);
        $this->getConnection($config);
		$this->server_name=$config;
		$this->setServer($config);
    }

    public function getConnection( $config_name ) {
        if (is_string($config_name) && $config_name!='dynamic') $config = Config::get($config_name);
		else
			$config=$this->getParams();
        if (isset($config['server'])) {
            $server_name = $config_name; //'mongocon_' . str_replace(".","_",$config['server']) . $config['port'];
			$this->server_name = $server_name;
            $this->server = $config['server'];
            if ( isset($config['read_tag']) ){
                $this->read_tag = $config['read_tag'];
            }
            if ( isset($config['read_tag_pref']) ){
                $this->read_tag_pref = $config['read_tag_pref'];
            }
            if (isset($config['port']) && !empty($config['port'])) $this->port = $config['port'];
            if (isset($config['server2']) && !empty($config['server2'])) $this->server2 = $config['server2'];
            if (isset($config['repset']) && !empty($config['repset'])) $this->repset = $config['repset'];
            
			/*COMMENTED BY ANSHU SINGH AS THERE IS NO USERNAME AND PASSWORD AUTHENTICATION*/
			
			//if (isset($config['username']) && !empty($config['username'])) $this->username = $config['username'];
            //if (isset($config['password']) && !empty($config['password'])) $this->password = $config['password'];
			
            if (isset($config['readPreference']) && !empty($config['readPreference'])) $this->readPreference = $config['readPreference'];
            if(!isSet(self::$con[$server_name]) || !is_object(self::$con[$server_name])){
                self::$con[$server_name] = self::getMongoConn( $config, $server_name );
            }	
        
        } else {
            throw new Exception('Invalid config passed ' . __LINE__ . __FILE__ );
            return false;
        }
        
        if ( isset($config['db']) && !empty($config['db']) && (self::$con) ) {
            $this->getDatabase($config['db']);
        }
        
        if ( isset($config['coll']) && !empty($config['coll']) && ($this->db) ) {
            $this->getCollection($config['coll']);
        }
        
        return $this;
    }
    
    public function getDatabase($db = null) {
        
        if ( (!$db) && ($this->db)) { return $this; }
        if (!self::$con) { throw new Exception('No mongo connection available' . __LINE__ . __FILE__ );  }
        if (!$db) { throw new Exception('No database name passed' . __LINE__ . __FILE__ );  }
        $this->db = self::$con[$this->server_name]->selectDB( $db );
        // Added read tag support for mongo
        if($this->read_tag){            
            $pref = MongoClient::RP_SECONDARY_PREFERRED;
            if($this->read_tag_pref == 'SECONDARY'){
                $pref = MongoClient::RP_SECONDARY;
            }else if($this->read_tag_pref == 'NEAREST'){
                $pref = MongoClient::RP_NEAREST;
            }else if($this->read_tag_pref == 'PRIMARY'){
                $pref = MongoClient::RP_PRIMARY;
            }else if($this->read_tag_pref == 'PRIMARY_PREFERRED'){
                $pref = MongoClient::RP_PRIMARY_PREFERRED;
            }
            
            $this->db->setReadPreference( $pref, array(
                array('tc' => $this->read_tag),
            ));
        }
        
        return $this;
    }
    
    public function setCollection($coll = null) {
        $server_name=$this->getServer();
        if ( (!$coll) && ($this->coll) ) { return $this; }
        if (!self::$con[$server_name]) { throw new Exception('No mongo connection available' . __LINE__ . __FILE__ );  }
        if (!$this->db) { throw new Exception('No database name passed' . __LINE__ . __FILE__ );  }
        if (!$coll) { throw new Exception('No collection name passed' . __LINE__ . __FILE__ );  }
        $this->coll = new MongoCollection( $this->db, $coll );
        
        return $this;
    }
    
    public function getCollection() {
        return $this->coll;
    }

    public function getData($id) {

        $this->checkCollection();
        $coll = $this->coll;
        $data = $coll->findOne(array('_id' => $id));

        return $data;
    }
    
    public function getAllData($where=array()) {

        $this->checkCollection();
        $coll = $this->coll;
        $data = $coll->find($where);
		$data = iterator_to_array($data);	
        return $data;
    }
    
    public function getDataByVar($var,$type) {

        $this->checkCollection();
        $coll = $this->coll;
        $data = $coll->findOne(array($type => $var));

        return $data;
    }
      
    public function getDataByGroup($where) {

        $this->checkCollection();
        $coll = $this->coll;
        $data = $coll->findOne($where);

        return $data;
    }
    
    public function save($data = null) {
        
        $this->checkCollection();
        $coll = $this->coll;
        
        return $coll->insert($data); //can be modified to update if _id isset or insert otherwise
    }

    public function update(array $critieria, $data = null, $options=array()) {
        $this->checkCollection();
        $coll = $this->getCollection();
        return $coll->update($critieria, $data, $options); //can be modified to update if _id isset or insert otherwise
    }
    
    private function checkCollection () {
        if (!self::$con[$this->server_name]) { throw new Exception('No mongo connection available' . __LINE__ . __FILE__ );  }
        if (!$this->db) { throw new Exception('No database name passed' . __LINE__ . __FILE__ );  }
        if (!$this->coll) { throw new Exception('No collection name passed' . __LINE__ . __FILE__ );  }
        
        return true;
    }
    
    static function getMongoConn(Array $conf, $server_name)
    {
		 
        //$server_name = 'mongocon_' . str_replace(".","_",$conf['server']) . $conf['port'];
        $mongo_class = 'MongoClient';
        if(!class_exists($mongo_class)){
            $mongo_class = 'Mongo';
        } 
	if (!isset(self::$con[$server_name])) self::$con[$server_name] = null;       

        if (self::$con[$server_name] === null)
            {
                try {
                    if(isSet($conf['server']) && isSet($conf['port'])){
                        if(isSet($conf['repset'])){
                            if(isSet($conf['username'])){
                                $m = new $mongo_class('mongodb://' . $conf['server'] . ':'. $conf['port'] .',' . $conf['server2'] . ':'. $conf['port'], array('username' => $conf['username'], 'password' => $conf['password'], 'replicaSet' => $conf['repset'], 'db' => $conf['db'],'readPreference' => $conf['readPreference']));
                            }else{
                                $m = new $mongo_class('mongodb://' . $conf['server'] . ':'. $conf['port'] .',' . $conf['server2'] . ':'. $conf['port'], array('replicaSet' => $conf['repset'], 'db' => $conf['db'],'readPreference' => $conf['readPreference']));
                            }
                        }                        
                        else
                            $m = new $mongo_class('mongodb://' . $conf['server'] . ':'. $conf['port'] );
                            //$m = new $mongo_class('mongodb://192.169.33.113:27017' );
                    }else{
                        die('Incomplete Server Config');
                    }
                        
				} catch (MongoConnectionException $e) {
                    die('Failed to connect to MongoDB '.$e->getMessage());
                }
                self::$con[$server_name] = $m;
            }
                
        return self::$con[$server_name];
            
    }
	public function setParam($name, $value){
        if($name && $value){
            $this->params[$name] = $value;
        }
    }
     
    function setParams($params){
        if($params){
            $this->params = $params;
        }
    }
    
    private function getParams(){
        return $this->params;
    }
	 private function setServer($Server){
        $this->server_name = $Server;
    }
    
    private function getServer(){
        return $this->server_name;
    }
}

?>
