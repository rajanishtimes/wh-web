<?php
namespace WH\Model\Util;

class Curl{
    
    public static function get($url, $params = null, $digest = false, $post=false){
		
        if (!function_exists('curl_init')) {
            return 'Sorry cURL is not installed!';
        }
        
        if($params){
            $url .= '?' . http_build_query($params);
        }
       
		/* THIS RETURN VARIABLE IS COMMENTED BY ANSHU AS WE NEED TO HAVE HTTP DIGEST IN CASE OF CMS API CALLS*/
		
        //return file_get_contents($url);
        
        //var_dump($url);
        $ip = $_SERVER['REMOTE_ADDR'];
        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, $url);
        
        if($post){
        curl_setopt($ch, CURLOPT_POST, 1);
        curl_setopt($ch, CURLOPT_POSTFIELDS, $params);
		}
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
		
		if(isset($params['reg_id'])){
			$uuid=$params['reg_id'];
			$headers[]="uuid:$uuid";
		}
		
		$headers[]="X_FORWARDED_FOR: $ip";
		$headers[]="REMOTE_ADDR: $ip";
		
		curl_setopt( $ch, CURLOPT_HTTPHEADER,$headers);
        
        if($digest){
            Curl::auth($ch);
        }
        
        $output = curl_exec($ch);
        if(curl_errno($ch)){
            error_log('curl error');
        }
        
        curl_close($ch);
        return $output;
    }
	
	public static function auth($ch){
		$digest =  "admin:admin";
		curl_setopt($ch, CURLOPT_HTTPAUTH, CURLAUTH_DIGEST);
		curl_setopt($ch, CURLOPT_USERPWD, $digest );
		curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
	}
}
?>
