<?php

/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

namespace WH\Model;

use WH\Model\Util\SQL;
use WH\Model\Util\StaticCon;
use WH\Model\Util\CmsApi;
use WH\Model\Util\Curl;
use WH\Model\Core\Config;
use SQLId as SQLId;

class User{
    
    private $results = array();
    private $SQL = null;
    private $CmsApi = null;
	
    function __construct() {
		
    }
   
    function setNewsletter(){
	   $SQL=StaticCon::getMySqlCon('frontEndDB');
		$this->setSQL($SQL);
    }
	
	function setProfile(){
		$CmsApi = new CmsApi();
        $CmsApi->setParam('id',$this->getId());
        $CmsApi->setApiType('critic/view');
        $CmsApi->setResultType('processProfile');
        $this->setCmsApi($CmsApi);
	}
	
	function setSSOParams(){
		$SQL=StaticCon::getMySqlCon('frontEndDB');
		$this->setSQL($SQL);
		$this->setSSOUrl(Config::get('ssoEndPoint'));
		$this->siteId = Config::get('ssoSiteId');
		$this->sitereg = Config::get('ssoSiteReg');
	}
	
	function setPostParams(){
		$CmsApi = new CmsApi();
        $CmsApi->setApiType('content/searchauthorid');
		$CmsApi->setParam('id',$this->getId());
		$CmsApi->setParam('start',$this->getStart());
		$CmsApi->setParam('limit',$this->getLimit());
        $CmsApi->setResultType('processPosts');
        $this->setCmsApi($CmsApi);
	}
	
    function getNewsletterResults (){
		$results=array();
		$this->insertNewsletter();
		$results = $this->getProcessResults('Added for newsletter successfully');	
        return $results;
    }
    
    function getUnsubNewsletterResults (){
		$results=array();
		$this->UnsubscribeNewsletter();
		$results = $this->getProcessResults('Unsubscribed for newsletter successfully');	
        return $results;
    }
    
    function getProfileResults (){
        $CmsApi = $this->getCmsApi();
        $CmsApi->call();
        $results = $CmsApi->getResults();
        return array(
            'profile'   => $results,
        );
    }
	
    function getPostsResults (){
        $CmsApi = $this->getCmsApi();
        $CmsApi->callpost();
        $response = $CmsApi->getResults();
		
		$start=$this->getStart();
		$limit=$this->getLimit();
		$results['meta']['match_count']=$response['total_count'];
		$results['meta']['start']=$start;
		$results['meta']['limit']=$limit;
		$results['results']=$response['contents'];
		return $results;
    }
	
	function registerUser(){
		$results=array();
		$postParams=$this->getParams();	
		if(!$this->isEmailExist()){
			$this->CheckEmailInLocal();
			$postParams['siteid'] = $this->siteId;
			$response=$this->ssorequest('InsertIntegraUserProfile', $postParams);
			$data=$this->getSSOResponse($response);
			$data=$this->processRegisterResponse($data);
			if(isSet($data['ErrCode'])){
				throw new \Exception( $data['Exception'],1 );
			} 
			else {
                if(isset($data['verification_code'])){
				$this->activateUser($data['verification_code']);
				$this->saveRegisterDataInDB($data);
				$results['user']=$this->processRegData($data);
                            }
			}
			return $results;
		}
		else{
			throw new \Exception('Email address already registered',1);
		}
	}
	
	
	private function isEmailExist()
	{
		$email='';
		$allparams=$this->getParams();
		if(isset($allparams['emailid']))
			$email=$allparams['emailid'];
		
		$params = array();
		
		if(empty($email)){
			$error = 'Email address is required';
			throw new \Exception($error,1);
		}
		$returnResult = false;
		$params['emailid'] = $email;
		$params['siteid'] = $this->siteId;
		$response=$this->ssorequest('isEmailIdAvailable',$params);
		$xmlContent = $this->getSSOResponse($response);
		
		if($xmlContent){
			if(isset($xmlContent->ErrCode) && $xmlContent->ErrCode == 'E108' || $xmlContent->ErrCode == 'E101'){
				$returnResult = $xmlContent->Message;
				throw new \Exception($returnResult,1);
			}else{
				$xmlContent = (array) $xmlContent;
				$returnResult = $xmlContent[0];
				if($returnResult == 0)
				return true;
				else
				return false;
			}
		}
		return $returnResult;
	}
	
	public function activateUser($hash_code)
	{
		$activateEmailparams = array();
		$returnResult = '';
		$action = 'ActivateEmailId';
		$activateEmailparams['hashcode'] = urlencode($hash_code);
		$activateEmailparams['siteid'] = $this->siteId;
		
		//call service
		$response=$this->ssorequest($action,$activateEmailparams);
		$xmlContent = simplexml_load_string($response);
		if($xmlContent){
			if(isset($xmlContent->ErrCode) && $xmlContent->ErrCode == 'E106'){
				throw new \Exception('Already Activated',1);
			} else {
				$xmlContent = (array) $xmlContent;
				$returnResult = $xmlContent[0];
				if($returnResult){
					//Account is activated
				}
			}
		}
		else{
		throw new Exception('SSO Did Not Return A Valid XML ' );
		}
		return $returnResult;
	}
	public function loginSocialUser(){		
		$postParams=$this->getParams();	
		$postParams['siteid'] = $this->siteId;
		$postParams['update'] = 'true';
		$postParams['showimage'] = 1;
		$postParams['createTicket'] = 'true';
		$response=$this->ssorequest('crossdomain/socialLogin', $postParams);
		$result=$this->processSocialLoginResponse($response);
		
		if(isSet($data['ErrCode'])){
			throw new \Exception( $data['Exception'],1 );
		} 
		$return['user']=$result;
		return $return;
	}
	
	public function loginUser(){
		$postParams=$this->getParams();	
		$postParams['siteId'] = $this->siteId;
		$response=$this->ssorequest('crossdomain/genericLogin', $postParams);		
		$result=$this->processLoginResponse($response);
		if(isSet($data['ErrCode'])){
			throw new \Exception( $data['Exception'],1 );
		} 
		$return['user']=$result;
		return $return;
	}
	
	public function processLoginResponse($response){
		$response=json_decode($response, true);
		if(isset($response['code'])){
			if($response['code'] == 200){
				$ticketId = $response['ticketId'];
				$userData = $this->get($ticketId);
				return $userData;
			}else{	
				throw new \Exception($response['error'],1);
			}
		}
		else{
			throw new \Exception('No Response From SSO Side',1);
		}
	}
	
	public function processSocialLoginResponse($response){
		$params=$this->getParams();
		$response = json_decode($response, true);
		
		if(is_array($response) && isSet($response['ticketId'])){
		$ticket = $response['ticketId'];
		$data = $this->get($ticket);
		
		if(is_array($data) && isSet($data['sso_id'])){
			if(isset($data['gender']) && $data['gender']!=''){
				$data['gender']=($data['gender']=='m')?'male':'female';
			}
			$sso_id = $data['sso_id'];
			$User=$this->CheckIfSocialUserAlreadyInDb($sso_id);
			if(!empty($User)){
				if(isSet($params['oauthsiteid']))
				{
					if($params['oauthsiteid'] == 'facebook')
					$data['source'] = 'facebook';
					else if($params['oauthsiteid'] == 'googleplus')
					$data['source'] = 'google';
				}
				$data['last_updated']=date('Y-m-d H:i:');
				$this->updateSocialProfile($data,$User[0]->id);
			}
			else{
				if(isSet($params['oauthsiteid']))
				{
					if($params['oauthsiteid'] == 'facebook')
					$data['source'] = 'facebook';
					else if($params['oauthsiteid'] == 'googleplus')
					$data['source'] = 'google';
				}
				$data['time_created']=date('Y-m-d H:i:');
				$data['time_joined']=date('Y-m-d H:i:');
				$this->saveSocialProfile($data);
			}
			return $data;
		}
		}
	}
	
	public function get($ticket){
		$raw_data = $this->validate_ticket($ticket);
		return $this->processUserData($raw_data);
	}
	public function validate_ticket($ticket){
		$params = array();
		$action = 'crossdomain/validateTicket';
		$params['ticketId'] = urlencode($ticket);
		$params['siteId'] = $this->siteId;
		$params['type'] = 'JSON';
		$response=$this->ssorequest($action,$params);
		$data = json_decode($response, true);
		return $data;
	}
	
	function processUserData($userData){
		$data = array();
		if(is_array($userData)){
			$data['firstname'] = isSet($userData['firstName']) ? $userData['firstName'] : '';
			$data['lastname'] = isSet($userData['lastName']) ? $userData['lastName'] : '';
			$data['date_of_birth'] = isSet($userData['dob']) ? date('Y-m-d', strtotime($userData['dob'])) : '';
			$data['gender'] = isSet($userData['gender']) ? $userData['gender'] : '';
			$data['phone'] = isSet($userData['mobile']) ? $userData['mobile'] : '';
			//$data['user_type'] = isSet($userData['userType']) ? $userData['userType'] : '';
			$data['sso_id'] = $userData['userId'];
			$data['email'] = $userData['emailId'];
		}
		return $data;
	}
	
	function processRegData($userData){
		$data = array();
		if(is_array($userData)){
			$data['firstname'] = isSet($userData['firstname']) ? $userData['firstname'] : '';
			$data['lastname'] = isSet($userData['lastname']) ? $userData['lastname'] : '';
			$data['date_of_birth'] = isSet($userData['dob']) ? $userData['dob'] : '';
			$data['gender'] = isSet($userData['gender']) ? $userData['gender'] : '';
			$data['phone'] = isSet($userData['mobile']) ? $userData['mobile'] : '';
			$data['sso_id'] = $userData['sso_id'];
			$data['email'] = $userData['email'];
		}
		return $data;
	}
	public function ssorequest ($url,$params)
	{
		$params['sitereg'] = $this->sitereg;	
		$params = array_map ( function ( $val ) { return join ( ',', (array) $val ); }, $params );
		$url = $this->getSSOUrl() . $url;
		$post = http_build_query ( $params, '', '&' );
		$url = $url . '?' . $post;
		$response = Curl::get($url);
		return $response;
	}
	
	public function getSSOResponse ($response)
	{
		$result = $response;
		$result = str_replace("&"," and ",$result);
		$result = str_replace(" & "," and ",$result);
		$xmlContent = simplexml_load_string($result);
		return $xmlContent;
	}
	
	private function processRegisterResponse($xmlContent)
	{
		$data = array();
		if($xmlContent){
			if(isset($xmlContent->ErrCode)){
				$data['ErrCode'] = $xmlContent->ErrCode;
				$data['Message'] = $xmlContent->Message;
				$data['Exception'] = $xmlContent->Exception;
			}
			else if(isset($xmlContent->Table)){
				if(isSet($xmlContent->VerificationCode))
				$data['verification_code'] = (string) $xmlContent->VerificationCode;
			
				$content = (array) $xmlContent->Table;
				$data['sso_id'] = $content['usr_id_vc'];
				$data['firstname'] = is_array($content) && isSet($content['frst_nm_vc']) && is_string($content['frst_nm_vc']) ? $content['frst_nm_vc'] : ' ';
				$data['lastname'] = is_array($content) && isSet($content['lst_nm_vc']) && is_string($content['lst_nm_vc']) ? $content['lst_nm_vc'] : ' ';
				$data['email'] = $content['eml_vc'];
				$data['city'] = (isSet($content['city'])&& is_string($content['city']) ) ? $content['city'] : '';
				$data['phone'] = (isSet($content['mobilephone']) && is_string($content['mobilephone']) ) ? $content['mobilephone'] : '';
				//$data['user_type'] = (isSet($content['userType']) && is_string($content['userType'])) ? $content['userType'] : 'WhatsHot';
				$data['gender'] = (isSet($content['Gender']) && is_string($content['Gender'])) ? $content['Gender'] : '';
				$data['date_of_birth'] = (isSet($content['dob']) && is_string($content['dob'])) ? date('Y-m-d',strtotime($content['dob'])) : '';
				$data['source'] = 'email';	// When user is registered directly using his email address. 2 for facebook and 3 for google+
			}
		}
		return $data;
	}
	public function CheckIfSocialUserAlreadyInDb($sso_id){
		$SQL=$this->getSQL();
		$where=array('sso_id'=>$sso_id);
		$query1=$SQL->select('id')->from('wh_users')->where($where)->get()->result_object();		
		$userexsts=$SQL->num_rows();
		return $query1;
	}
	
    function setEmail($email){
        $this->Email = $email;
    }
    
    private function getEmail(){
        return $this->Email;
    }
	
    function setId($id){
        $this->profile_id = $id;
    }
    
    private function getId(){
        return $this->profile_id;
    }
	
    function setStart($start){
        $this->start = $start;
    }
    
    private function getStart(){
        return $this->start;
    }
	
    function setLimit($limit){
        $this->limit = $limit;
    }
    
    private function getLimit(){
        return $this->limit;
    }
	
	public function setParam($name, $value){
        if($name && $value){
            $this->params[$name] = $value;
        }
    }
    
    private function getParams(){
        return $this->params;
    }
    
	private function getProcessResults($message){
		return array(
			'done'=>1,
			'message'=>$message
		);
		
	}
	private function setSQL($SQL){
        $this->SQL = $SQL;
    }
    
    private function getSQL(){
        return $this->SQL;
    }
	
	private function setSSOUrl($SSO){
        $this->SSOUrl = $SSO;
    }
    
    private function getSSOUrl(){
        return $this->SSOUrl;
    }
	
    private function setCmsApi($CmsApi){
        $this->CmsApi = $CmsApi;
    }
    
    private function getCmsApi(){
        return $this->CmsApi;
    }
	
	private function checkIfEmailExists(){
		$SQL=$this->getSQL();
		$email=$this->getEmail();
		$where=array('email'=>$email);
		$emailexists=$SQL->select('email,status')->from('wh_newsletters')->where($where)->get()->result_object();		
		return $emailexists;
	}

	private function CheckEmailInLocal(){
		$SQL=$this->getSQL();
		$allParams=$this->getParams();
		$where=array('email'=>$allParams['emailid']);
		$query=$SQL->select('*')->from('wh_users')->where($where)->get();		
		$emailexists=$SQL->num_rows();
		if($emailexists>0)
			return true;
	}

	private function insertNewsletter(){
		$SQL=$this->getSQL();
		$email=$this->getEmail();
		$emailexists= $this->checkIfEmailExists();
		$data=array('email'=>$email,'time_added'=>date('Y-m-d H:i:s'),'status'=>1);
		if(!empty($emailexists)){
			if($emailexists[0]->status==0){// user has unsubscribed
				$where=array('email'=>$email);
				$query=$SQL->update('wh_newsletters',$data,$where);
				if(!$query)
					throw new \Exception("Something went wrong while subscribing!",1); 
			}
			else{
				throw new \Exception("This email is already subscribed to our newsletter",1);
			}
		}
		else{
			$query=$SQL->insert('wh_newsletters',$data);
		if(!$query)
			throw new \Exception("Something went wrong while subscribing!",1); 
		}
	}
	
	private function UnsubscribeNewsletter(){
		$SQL=$this->getSQL();
		$email=$this->getEmail();
		$emailexists= $this->checkIfEmailExists();
		$data=array('status'=>0);
		if(!empty($emailexists)){
			if($emailexists[0]->status==0){// user has unsubscribed
				throw new \Exception("You have already unsubscribed!",1);
			}
			else{
				$where=array('email'=>$email);
				$query=$SQL->update('wh_newsletters',$data,$where);
				if(!$query)
					throw new \Exception("Something went wrong while unsubscribing!",1);
			}
		}
		else{
			throw new \Exception("You have not subscribed yet!",1);
		}
	}
	
	private function saveRegisterDataInDB($data){
		$SQL=$this->getSQL();
		$data['time_created']=date('Y-m-d H:i:s');
		$data['time_joined']=date('Y-m-d H:i:s');
		$query=$SQL->insert('wh_users',$data);
		if(!$query)
			throw new \Exception("Something went wrong while saving your details to local database!",1); 
	}
	
	public function updateSocialProfile($data,$id){
		if(!empty($data)){
			$explode_email = explode('@', $data['email']);
			
			if ( !isset($data['firstname']) || empty($data['firstname']) ){
			$data['firstname'] = $explode_email[0];
			}
			$SQL=$this->getSQL();
			$where=array('id'=>$id);
			$query=$SQL->update('wh_users',$data,$where);
			$allParams=$this->getParams();
			if(isset($allParams['reg_id'])){
				$data2['user_id'] = $id;
				$where=array('reg_id'=>$allParams['reg_id']);
				$query=$SQL->update('wh_pn_tokens',$data2,$where);
			}
            return $data;
			
		}
	}
	
	
	public function saveSocialProfile($data){
		if(!empty($data)){
			$explode_email = explode('@', $data['email']);
			
			if ( !isset($data['firstname']) || empty($data['firstname']) ){
			$data['firstname'] = $explode_email[0];
			}
			$SQL=$this->getSQL();
			$query=$SQL->insert('wh_users',$data);
			if(!$query)
				throw new \Exception("Something went wrong while saving your details to local database!",1); 
			
			$userid=$SQL->insert_id();
			$allParams=$this->getParams();
			if(isset($allParams['reg_id'])){
				$data2['user_id'] = $userid;
				$where=array('reg_id'=>$allParams['reg_id']);
				$query=$SQL->update('wh_pn_tokens',$data2,$where);
			}
		}
	}
}
