<?php

namespace WH\Model;
use WH\Model\Util\WhMongo;
use WH\Model\Core\Constants as C;
use MongoId as MongoId;  
 
class Report{
	
	public function allLogs(){
		$Mongo=new WhMongo();
		$this->setMongo($Mongo);		
		$this->allSolrLogs();
		
	}
	
	private function allSolrLogs(){
		$returnData='';
		$Mongo=$this->getMongo();
		$Mongo->setCollection('api_logs');
		$date=date('Y-m-d').' 00:00:00';
		$newDate=strtotime($date);
		$where=array('created'=>array( '$gt' => $newDate ));
		$allSolrData=$Mongo->getAllData($where);
		if(!empty($allSolrData)){
			foreach($allSolrData as $allData){
				if($allData['env']=='qc')
					$allQCLogs[]=$allData;
				
				else if($allData['env']=='appapi')
					$allDevLogs[]=$allData;
				
				else if($allData['env']=='content')
					$allContentLogs[]=$allData;
				
				else
					$allStagingLogs[]=$allData;
			}
			if(!empty($allContentLogs)){
				$returnData='<h3>Environment : Content</h3><br/>';
				$ContentLogs=$this->processLogs($allContentLogs);
				if(!empty($ContentLogs)){
					$returnData.=$this->prepareHTML($ContentLogs);
				}
			}
			if(!empty($allQCLogs)){
				$QCLogs=$this->processLogs($allQCLogs);
				$returnData.='<h3>Environment : QC</h3><br/>';
				if(!empty($QCLogs)){
					$returnData.=$this->prepareHTML($QCLogs);
				}
			}
			if(!empty($allDevLogs)){
				$returnData.='<h3>Environment : Dev</h3><br/>';
				$DevLogs=$this->processLogs($allDevLogs);
				if(!empty($DevLogs)){
					$returnData.=$this->prepareHTML($DevLogs);
				}
			}
			if(!empty($allStagingLogs)){
				$returnData.='<h3>Environment : Staging</h3><br/>';
				$StagingLogs=$this->processLogs($allStagingLogs);
				if(!empty($StagingLogs)){
					$returnData.=$this->prepareHTML($StagingLogs);
				}
			}
			$this->sendLogsInEmail($returnData);
			exit;
		}
		
	}
	
	private function sendLogsInEmail($data){
		require_once C::root(). '/'.C::env().'/Lib/PHPMailer/PHPMailerAutoload.php';
		
		$subject="What's Hot performance logs for ".date('F d, Y');
		$fromname="What's Hot";
		$email='anshu@timescity.com';
		
        $mail = new \PHPMailer;
        $mail->isSMTP();                                      // Set mailer to use SMTP
        $mail->Host = 'cmailer.indiatimes.com';  // Specify main and backup server
        $mail->SMTPAuth = false;                               // Enable SMTP authentication
        $mail->Port = 25;  
		//$mail->SMTPDebug  = 1;
        $mail->From = 'info@whatshot.in';
        $mail->FromName = $fromname; 
        $mail->addAddress($email);
        $mail->addCc('srijan@whatshot.in');
        $mail->isHTML(true);                                  // Set email format to HTML
    
        $mail->Subject = $subject;
        $mail->Body    = $data;
		
        if(!$mail->send())
		echo 'Not Sent';
		
		else
			echo 'Email Sent';
		exit;
	}
	
	private function prepareHTML($Logs){
		$returnData='<b>For Solr APIs :</b> <br/>';
		$returnData.='<table border="1" style="margin-top:15px">';
		$returnData.='<tr><th>Type</th><th>Lowest Time</th><th>Highest Time</th><th>Average Time</th></tr>';
		$returnData.='<tr><td style="padding:5px">Solr Time:</td><td style="padding:5px">'.$Logs['lt1'].'</td><td style="padding:5px">'.$Logs['ht1'].'</td><td style="padding:5px">'.$Logs['solr_avg_time'].'</td>';
		$returnData.='<tr><td style="padding:5px">Time to get Solr Response in API:</td><td style="padding:5px">'.$Logs['lt2'].'</td><td style="padding:5px">'.$Logs['ht2'].'</td><td style="padding:5px">'.$Logs['solr_avg_call_time'].'</td>';
		$returnData.='<tr><td style="padding:5px">Average time to process API (Solr + Processing):</td><td style="padding:5px">'.$Logs['lt3'].'</td><td style="padding:5px">'.$Logs['ht3'].'</td><td style="padding:5px">'.$Logs['solr_avg_response_time'].'</td>';
		$returnData.='</table>';
		$returnData.='<br/><b>For Non Solr APIs :</b> <br/>';
		$returnData.='<table border="1" style="margin-top:15px">';
		$returnData.='<tr><td style="padding:5px">Average time to process API:</td><td style="padding:5px">'.$Logs['lt4'].'</td><td style="padding:5px">'.$Logs['ht4'].'</td><td style="padding:5px">'.$Logs['avg_response_time'].'</td>';
		$returnData.='</table><br/><br/>';
		return $returnData;
		
	}
	private function processLogs($allData){
		$solrData=array();
		$nonsolrData=array();
		$ResponseTime=array();
		if(!empty($allData)){
			$ht1=0;
			$ht2=0;
			$ht3=0;
			$ht4=0;
			$lt1=10000000000;
			$lt2=10000000000;
			$lt3=10000000000;
			$lt4=10000000000;
			foreach($allData as $data){
				if($data['solr_time']>0 && $data['solr_call_time']>0)
					$solrData[]=$data;
				else
					$nonsolrData[]=$data;
			}
			if(!empty($solrData)){
				$i=0;
				$solr_time=0;
				$solr_call_time=0;
				$total_response_time=0;
				foreach($solrData as $solrD){
					$i++;
					$solr_time=$solr_time+$solrD['solr_time'];
					$solr_call_time=$solr_call_time+$solrD['solr_call_time'];
					$total_response_time=$total_response_time+$solrD['response_time'];
					
					if($ht1<$solrD['solr_time'])
						$ht1=$solrD['solr_time'];
					
					if($lt1>$solrD['solr_time'])
						$lt1=$solrD['solr_time'];
					
					if($ht2<$solrD['solr_call_time'])
						$ht2=$solrD['solr_call_time'];
					
					if($lt2>$solrD['solr_call_time'])
						$lt2=$solrD['solr_call_time'];
					
					if($ht3<$solrD['response_time'])
						$ht3=$solrD['response_time'];
					
					if($lt3>$solrD['response_time'])
						$lt3=$solrD['response_time'];
				}
				$ResponseTime['solr_avg_time']=$solr_time/$i;
				$ResponseTime['solr_avg_call_time']=$solr_call_time/$i;
				$ResponseTime['solr_avg_response_time']=$total_response_time/$i;
			}
			
			if(!empty($nonsolrData)){
				$i=0;
				$response_time=0;
				foreach($nonsolrData as $nonsolrD){
					$i++;
					$response_time=$response_time+$nonsolrD['response_time'];
					
					if($ht4<$nonsolrD['response_time'])
						$ht4=$nonsolrD['response_time'];
					
					if($lt4>$nonsolrD['response_time'])
						$lt4=$nonsolrD['response_time'];
				}
				$ResponseTime['avg_response_time']=$total_response_time/$i;
				$ResponseTime['lt1']=$lt1;
				$ResponseTime['lt2']=$lt2;
				$ResponseTime['lt3']=$lt3;
				$ResponseTime['lt4']=$lt4;
				$ResponseTime['ht1']=$ht1;
				$ResponseTime['ht2']=$ht2;
				$ResponseTime['ht3']=$ht3;
				$ResponseTime['ht4']=$ht4;
			}
			
		}
		return $ResponseTime;
	}
	
	private function setMongo($Mongo){
		$this->Mongo=$Mongo;
	}
	
	private function getMongo(){
		return $this->Mongo;
	}
	
	public function sendEmail($fromname,$email,$subject,$body,$campaign,$src,$tag){
		$token=$this->getToken();		
		$image='<img src="http://'.C::base().'/'.C::env().'/c.gif?token='.$token.'">';
		$message = $body.'<br/><br/>'.$image;
		
		require_once C::root(). '/'.C::env().'/Lib/PHPMailer/PHPMailerAutoload.php';
        $mail = new \PHPMailer;
        $mail->isSMTP();                                      // Set mailer to use SMTP
        $mail->Host = 'cmailer.indiatimes.com';  // Specify main and backup server
        $mail->SMTPAuth = false;                               // Enable SMTP authentication
        $mail->Port = 25;  
		//$mail->SMTPDebug  = 1;
        $mail->From = 'info@whatshot.in';
        $mail->FromName = $fromname; 
        $mail->addAddress($email);
        $mail->isHTML(true);                                  // Set email format to HTML
    
        $mail->Subject = $subject;
        $mail->Body    = $message;
        if(!$mail->send()) { 
            $return['status']=0;
			$return['message']= $mail->ErrorInfo;
			$return['ukey']=$token;
			return $return;
        }else{
            $this->saveEmailInDb($email,$subject,$message,$campaign,$src,$tag,$token);				
			$return['status']=1;
			$return['message']='Success';
			$return['ukey']=$token;
			return $return;
        }
	}
	
    function setParam($name, $value){
        if($name && $value){
            $this->params[$name] = $value;
        }
    }
	
    private function getParams(){
        return $this->params;
    }
	
	private function getToken(){
		return substr(str_shuffle("0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ"), 0, 20);
	}
}
