<?php

/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

namespace WH\Model;
use WH\Model\Util\StaticCon;
use WH\Model\Util\SQL;

class Core{
    
    private $results = array();
    private $CmsApi = null;
    
    function __construct() {
       $SQL=StaticCon::getMySqlCon('CmsDB');
        $this->setSQL($SQL);  
    }
	
    private function setSQL($SQL){
        $this->SQL = $SQL;
    }
    
    private function getSQL(){
        return $this->SQL;
    }
    public function setCity($City){
        $this->City = $City;
    }
    
    private function getCity(){
        return $this->City;
    }
	public function setParam($name, $value){
        if($name && $value){
            $this->params[$name] = $value;
        }
    }
    
    private function getParams(){
        return $this->params;
    }
    
   function getResults (){
		$result=array();
		$SQL=$this->getSQL();
		$where=array('city_id'=>$this->getCity(),'status'=>1);
		$alltags=$SQL->select('name')->from('tc_popular_tags')->where($where)->get()->result_array();
		if(!empty($alltags)){
			foreach($alltags as $tag){
				$result['popular_tags'][]=$tag['name'];
			}
		}
		return $result;
    }
}