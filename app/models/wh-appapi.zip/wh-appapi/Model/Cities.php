<?php

/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

namespace WH\Model;

use WH\Model\Util\CmsApi;

class Cities{
    
    private $results = array();
    private $CmsApi = null;
    
    function __construct() {
        $CmsApi = new CmsApi();
        $CmsApi->setApiType('city/index');
        $CmsApi->setResultType('processCity');
        $this->setCmsApi($CmsApi);
        
    }
    //THIS FUNCTION IS CALLED FROM CONSTANT FILE
	
	function allCities(){
		$CmsApi = $this->getCmsApi();
        $CmsApi->call();
        $results = $CmsApi->getResults();
		return $this->processConstantCities($results);
	}
	
    function getResults (){
        $CmsApi = $this->getCmsApi();
		
        $CmsApi->call();
        $results = $CmsApi->getResults();
        return array(
            'cities'   => $results,
        );
    }
    
    private function setCmsApi($CmsApi){
        $this->CmsApi = $CmsApi;
    }
    
    private function getCmsApi(){
        return $this->CmsApi;
    }
	public function setParam($name, $value){
        if($name && $value){
            $this->params[$name] = $value;
        }
    }
    
    private function getParams(){
        return $this->params;
    }
    
	private function processConstantCities($results){
		$return=array();
		if(!empty($results)){
			foreach($results as $result){
				$return[$result['id']]=$result['name'];
			}
		}
		return $return;
	}
}